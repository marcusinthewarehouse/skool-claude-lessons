# Visual Art (Canvas Design)

## Overview

The Visual Art skill creates museum-quality visual artwork in PNG and PDF formats using a design philosophy approach. This skill produces sophisticated, original artwork for posters, prints, and visual pieces with professional-grade aesthetic quality suitable for galleries, magazines, and high-end applications.

## Who Should Use This Skill

- **Graphic Designers** creating professional posters and print materials
- **Art Directors** developing visual concepts for campaigns
- **Brand Designers** producing high-quality branded visual assets
- **Creative Professionals** needing sophisticated static artwork
- **Marketing Teams** creating premium visual content
- **Anyone** wanting museum or magazine-quality visual designs

## Purpose and Use Cases

Use this skill when you need to:
- Create professional posters and art prints
- Design sophisticated visual branding materials
- Produce magazine-quality layouts and compositions
- Develop original visual art pieces with conceptual depth
- Create multi-page layouts for series or book designs

**Keywords that trigger this skill:** poster, art, design, visual design, print design, canvas artwork

## What's Included

### Two-Step Creative Process

**Step 1: Design Philosophy Development**
- Develop a 4-6 paragraph philosophical framework describing the visual approach
- Focus on: form, space, color, composition, images, graphics, shapes, patterns
- Minimal text emphasis - prioritize visual elements
- Create original conceptual frameworks (never copy existing artists)
- Establish sophisticated, art-focused aesthetic principles

**Step 2: Visual Expression on Canvas**
- Translate the philosophy into concrete visual design
- Implement using professional design tools and canvas APIs
- Output as high-resolution PNG or PDF

### Design Philosophy Examples

**Concrete Poetry:**
Monumental form and bold geometry - strong shapes that command attention through scale and precision

**Chromatic Language:**
Color as an information system - hues, values, and saturations creating visual communication without words

**Analog Meditation:**
Texture and breathing room - tactile quality and generous negative space for contemplative viewing

**Organic Systems:**
Natural clustering and modular growth - patterns that feel alive, following biological organization principles

**Geometric Silence:**
Pure order and restraint - minimalist geometric compositions emphasizing the power of simplicity

### Output Formats

**Documentation:**
- `.md` file containing the complete design philosophy (4-6 paragraphs)
- Conceptual foundation that informs the visual work

**Artwork:**
- `.pdf` for vector-based designs requiring scalability
- `.png` for raster artwork with rich visual detail
- High resolution suitable for print reproduction
- Professional color management

**Multi-Page Options:**
- Series of related pieces following a single philosophy
- Book layouts with visual continuity across pages
- Sequential narratives told through visual language

## How It Works

### Step-by-Step Process

**1. Conceptual Development**
- Define the visual philosophy in 4-6 detailed paragraphs
- Establish principles for form, color, composition, and space
- Determine the emotional and aesthetic goals
- Plan the relationship between concept and execution

**2. Design Specification**
- Translate philosophy into specific visual decisions
- Define color palette based on conceptual approach
- Plan composition, typography (if any), and layout
- Determine format (single piece vs. multi-page)

**3. Visual Execution**
- Create the artwork using canvas APIs and design tools
- Implement the philosophy through visual elements
- Ensure museum/magazine quality standards
- Maintain sophistication and artistic integrity

**4. Output Generation**
- Render as high-resolution PNG or PDF
- Ensure proper color space and resolution
- Optimize for intended use (print vs. digital)
- Package with conceptual documentation

**5. Delivery**
- Present the philosophy (.md file)
- Share the final artwork (.pdf or .png)
- Explain how visual choices express the concepts

### Quality Standards

**Aesthetic Requirements:**
- Museum or magazine quality work only
- Sophisticated, art-focused approach
- **Never** cartoony or amateur-looking
- Professional color relationships
- Thoughtful composition and balance

**Technical Requirements:**
- High resolution for print reproduction
- Proper color management
- Clean, precise execution
- Format appropriate to content

## Technical Details

### Design Elements

**Form and Shape:**
- Geometric or organic forms based on philosophy
- Precise execution with clean edges or intentional texture
- Scale and proportion creating visual hierarchy
- Positive and negative space relationships

**Color Application:**
- Sophisticated color palettes (never garish)
- Harmonious relationships (complementary, analogous, monochromatic)
- Color as meaning-maker, not decoration
- Consideration of cultural and emotional associations

**Composition:**
- Grid systems or organic arrangements
- Balance (symmetrical, asymmetrical, or radial)
- Visual flow guiding the viewer's eye
- Generous use of white/negative space

**Typography (when used):**
- Minimal, purposeful text integration
- Typography as visual element, not just information carrier
- Font selection supporting the philosophy
- Text-image relationships creating unified whole

**Texture and Pattern:**
- Intentional surface quality (smooth, rough, layered)
- Repetition creating rhythm or visual interest
- Patterns following natural or geometric logic
- Depth through layering or dimensional suggestion

### Output Specifications

**PDF Format:**
- Vector-based when possible for perfect scalability
- High-quality raster images when needed
- Print-ready color space (CMYK option)
- Embedded fonts if typography included

**PNG Format:**
- 300 DPI minimum for print quality
- RGB color space for digital display
- Transparent backgrounds when appropriate
- Optimized file size without quality loss

## Use Cases and Examples

### Poster Design
- Concert posters with bold geometric forms
- Exhibition announcements with sophisticated typography
- Event posters using chromatic language approach
- Propaganda-style designs with strong visual impact

### Art Prints
- Limited edition prints with organic systems
- Gallery-quality pieces using geometric silence
- Series of related works exploring single philosophy
- Abstract compositions with concrete poetry influence

### Brand Visual Assets
- Premium brand imagery with analog meditation
- Visual identity pieces using modular systems
- Sophisticated backgrounds and brand environments
- Print materials reflecting brand philosophy

### Multi-Page Layouts
- Art book layouts with consistent visual language
- Series of posters telling visual story
- Magazine spreads with sophisticated design
- Sequential pieces exploring philosophical concept

## Best Practices

### Philosophy Development
- **Be specific and detailed** - vague philosophies produce weak work
- **Focus on visual elements** - form, color, space, not verbose concepts
- **Create original frameworks** - never copy existing artists or movements
- **Let philosophy guide decisions** - every visual choice should reflect concepts
- **Maintain sophistication** - museum/magazine quality standards

### Visual Execution
- **Prioritize quality over quantity** - one excellent piece beats multiple mediocre ones
- **Use restraint** - avoid visual clutter and unnecessary elements
- **Consider the viewer** - create work that rewards contemplation
- **Maintain integrity** - never compromise sophistication for mass appeal
- **Test at intended size** - ensure design works at final output dimensions

### Technical Considerations
- **Choose appropriate format** - PDF for scalability, PNG for rich detail
- **Ensure sufficient resolution** - 300 DPI minimum for any print application
- **Manage colors carefully** - test how palette works in final output
- **Consider context** - where and how will the work be displayed?
- **Document the process** - philosophy file explains the thinking

### Common Pitfalls to Avoid
- ❌ Generic or clichéd visual approaches
- ❌ Amateur or cartoony aesthetics
- ❌ Overly busy compositions without breathing room
- ❌ Color choices that fight rather than harmonize
- ❌ Text-heavy designs when visual communication would be stronger
- ❌ Low resolution outputs unsuitable for intended use
- ❌ Philosophy disconnected from visual execution