# Generative Art (Algorithmic Art)

## Overview

The Generative Art skill enables the creation of original algorithmic art using p5.js with computational processes, mathematical beauty, and seeded randomness. This skill produces interactive artifacts where users can explore different variations through seed navigation and real-time parameter adjustments.

## Who Should Use This Skill

- **Artists and Designers** exploring computational creativity and algorithmic aesthetics
- **Developers** interested in creating generative art systems and interactive visualizations
- **Creative Coders** building art installations, visual experiments, or flow field systems
- **Anyone** wanting to create unique, code-based artwork with mathematical foundations

## Purpose and Use Cases

Use this skill when you want to:
- Create original generative art pieces using code
- Build algorithmic visualizations with emergent behavior
- Design interactive art systems with parameter controls
- Explore flow fields, particle systems, or mathematical patterns
- Generate seeded artwork where each seed produces a unique piece

**Keywords that trigger this skill:** generative art, algorithmic art, p5.js, computational art, flow fields, particle systems

## What's Included

### Two-Step Creative Process

**Step 1: Algorithmic Philosophy Development**
- Develop a 4-6 paragraph philosophical framework that describes the computational approach
- Focus on: computational processes, emergent behavior, mathematical beauty, seeded randomness
- Avoid copying existing artists - create original conceptual frameworks
- Example philosophies: Organic Turbulence, Quantum Harmonics, Recursive Whispers, Field Dynamics, Stochastic Crystallization

**Step 2: Visual Expression in p5.js**
- Translate the philosophy into working p5.js code
- Implement seeded randomness for reproducible variations
- Create interactive controls for real-time parameter tuning

### Interactive Artifact Features

**Seed Navigation System:**
- Previous/Next seed buttons for sequential exploration
- Random seed button for discovery
- Jump-to-seed input for returning to specific pieces
- Each seed produces a unique, reproducible artwork

**Parameter Controls:**
- Real-time sliders for adjusting algorithmic parameters
- Interactive tuning of visual characteristics
- Live updates as parameters change

**Output Format:**
- Single HTML file with p5.js loaded from CDN
- Fully self-contained and shareable
- Works in any modern web browser

### Common Algorithmic Philosophies

**Organic Turbulence:**
Chaos constrained by natural law - unpredictable movement governed by underlying rules

**Quantum Harmonics:**
Wave-like interference patterns creating visual rhythms through mathematical superposition

**Recursive Whispers:**
Self-similarity across scales revealing patterns within patterns

**Field Dynamics:**
Invisible forces made visible through particle trajectories and vector fields

**Stochastic Crystallization:**
Random processes coalescing into ordered structures over time

## How It Works

1. **Conceptual Development:** Create an original algorithmic philosophy (4-6 paragraphs) describing the computational and aesthetic approach
2. **Technical Implementation:** Express the philosophy as p5.js code with proper randomness seeding
3. **Interactive Layer:** Add seed navigation (prev/next/random/jump) and parameter sliders
4. **Artifact Generation:** Bundle everything into a single interactive HTML file
5. **Delivery:** Present the artwork with its conceptual foundation and interactive controls

### Technical Details

- **Framework:** p5.js (loaded from CDN)
- **Randomness:** Seeded random number generation for reproducibility
- **Interactivity:** HTML controls (buttons, sliders) for navigation and parameters
- **Output:** Single HTML file artifact

### Example Algorithmic Elements

- Flow fields with noise-based vector fields
- Particle systems with emergent flocking behavior
- Recursive geometric patterns with self-similarity
- Mathematical functions creating organic-looking forms
- Stochastic processes producing unexpected beauty

## Best Practices

- Always start with the philosophical framework before coding
- Use seeded randomness (randomSeed() in p5.js) for reproducibility
- Create meaningful parameter controls that genuinely affect the artwork
- Focus on emergent behavior rather than predetermined outcomes
- Avoid copying existing generative artists - create original approaches
- Ensure each seed produces a distinctly different but conceptually related piece