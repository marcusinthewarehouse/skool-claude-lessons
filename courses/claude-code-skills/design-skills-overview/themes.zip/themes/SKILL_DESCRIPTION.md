# Theme Factory

## Overview

The Theme Factory skill provides a professional toolkit for applying consistent visual themes to artifacts including slides, documents, reports, and HTML landing pages. It offers 10 pre-set professional themes with coordinated colors and fonts, plus the ability to generate custom themes on-the-fly based on user requirements.

## Who Should Use This Skill

- **Designers** needing quick, professional theme application
- **Presenters** creating visually cohesive slide decks
- **Content Creators** producing branded documents and reports
- **Web Developers** styling HTML artifacts and landing pages
- **Marketing Teams** maintaining visual consistency across materials
- **Anyone** wanting professional-looking themed content

## Purpose and Use Cases

Use this skill when you need to:
- Apply a consistent visual theme to presentations, documents, or web artifacts
- Choose from professional pre-made themes with coordinated aesthetics
- Generate custom themes based on specific requirements or brand guidelines
- Ensure visual consistency across multiple artifacts
- Quickly style content with professional color and typography pairings

## What's Included

### 10 Pre-Set Professional Themes

Each theme includes a complete visual identity with:
- **Color palette** - Primary, secondary, accent, background, and text colors
- **Font pairings** - Heading and body fonts that complement each other
- **Visual identity** - Cohesive aesthetic that works across different media

**Theme Showcase:**
A visual PDF displays all 10 themes side-by-side, making it easy to see and compare the complete aesthetic of each option before choosing.

### The 10 Available Themes

**1. Ocean Depths**
- Deep blues and teals with aqua accents
- Modern, professional, trustworthy
- Perfect for: Corporate presentations, financial documents, technology content

**2. Sunset Boulevard**
- Warm oranges, pinks, and purples
- Energetic, creative, approachable
- Perfect for: Creative portfolios, marketing materials, event promotions

**3. Forest Canopy**
- Rich greens with earthy browns and soft beiges
- Natural, balanced, calming
- Perfect for: Environmental content, wellness materials, organic brands

**4. Modern Minimalist**
- Black, white, and subtle grays
- Clean, sophisticated, timeless
- Perfect for: Architecture, luxury brands, editorial content

**5. Golden Hour**
- Warm golds, oranges, and soft creams
- Optimistic, premium, inviting
- Perfect for: Lifestyle content, hospitality, premium products

**6. Arctic Frost**
- Cool whites, pale blues, and silver grays
- Crisp, clean, modern
- Perfect for: Technology, healthcare, minimalist brands

**7. Desert Rose**
- Terracotta, dusty rose, warm sands
- Earthy, sophisticated, warm
- Perfect for: Design content, boutique brands, artisanal products

**8. Tech Innovation**
- Electric blue, neon accents, dark backgrounds
- Futuristic, cutting-edge, dynamic
- Perfect for: Tech startups, innovation content, digital products

**9. Botanical Garden**
- Fresh greens, floral accents, natural tones
- Organic, fresh, vibrant
- Perfect for: Food content, natural products, growth-focused messaging

**10. Midnight Galaxy**
- Deep purples, cosmic blues, starlight whites
- Mysterious, premium, imaginative
- Perfect for: Creative content, entertainment, aspirational brands

### Custom Theme Generation

Beyond the 10 presets, the skill can generate custom themes based on:
- Specific color requirements or brand colors
- Desired mood or aesthetic direction
- Industry or use case needs
- Font preferences or restrictions
- Accessibility requirements

## How It Works

### Standard Theme Application Workflow

**Step 1: Show Theme Showcase**
Present the theme showcase PDF displaying all 10 options visually

**Step 2: Ask for User Choice**
Request the user to select their preferred theme from the 10 options

**Step 3: Wait for Selection**
Pause and allow the user to review and choose (critical - don't skip this step)

**Step 4: Apply Chosen Theme**
Apply the selected theme's complete color palette and typography to the artifact

### Custom Theme Workflow

**Step 1: Gather Requirements**
- What colors should be included or avoided?
- What mood or feeling should the theme convey?
- Are there brand guidelines to follow?
- What fonts are preferred or required?
- What's the primary use case (slides, web, documents)?

**Step 2: Generate Custom Theme**
Create a custom theme with:
- Coordinated color palette based on requirements
- Complementary font pairings
- Visual identity matching the desired aesthetic

**Step 3: Apply to Artifact**
Implement the custom theme consistently across the content

## Technical Details

### Theme Components

**Color Palette Structure:**
Each theme includes:
- **Primary color** - Main brand or dominant color
- **Secondary color** - Supporting color for variety
- **Accent color** - Highlights, calls-to-action, emphasis
- **Background color** - Page/slide backgrounds
- **Text color** - Primary text for readability
- **Light/dark variants** - For different contexts

**Typography Pairing:**
- **Heading font** - For titles, headers, emphasis text
- **Body font** - For paragraphs, details, readable content
- **Font weights** - Appropriate weights for hierarchy

**Application Guidelines:**
- Color usage ratios (60-30-10 rule)
- Contrast requirements for accessibility
- Font sizing scales
- Spacing and layout principles

### Supported Artifact Types

**Presentations (Slides):**
- Slide backgrounds
- Title and heading styles
- Body text formatting
- Accent colors for charts and callouts

**Documents and Reports:**
- Page backgrounds
- Heading hierarchy
- Body text styling
- Accent elements and highlights

**HTML Landing Pages:**
- CSS color variables
- Typography styles
- Button and link colors
- Section backgrounds

**General Artifacts:**
- Any visual content requiring cohesive theming

## Use Cases and Examples

### Corporate Presentation
**Theme:** Ocean Depths
- Deep blue slide backgrounds
- Teal accents for key points
- Professional sans-serif headings
- Readable serif body text
- Conveys trust and expertise

### Creative Portfolio
**Theme:** Sunset Boulevard
- Warm gradient backgrounds
- Pink and orange accents
- Modern, friendly typography
- Energetic and approachable feel

### Environmental Report
**Theme:** Forest Canopy
- Natural green color palette
- Earth-tone accents
- Organic typography choices
- Calm, balanced aesthetic

### Tech Product Landing Page
**Theme:** Tech Innovation
- Dark background with electric blue accents
- Neon highlights for CTAs
- Modern, sleek typography
- Futuristic, cutting-edge feel

### Wellness Brand Materials
**Theme:** Botanical Garden
- Fresh green backgrounds
- Floral accent colors
- Light, airy typography
- Natural, health-focused aesthetic

## Best Practices

### Theme Selection
- **Always show the showcase first** - visual selection is faster than descriptions
- **Wait for user input** - don't assume or choose for them
- **Consider the content** - match theme to message and audience
- **Think about context** - where will this be viewed? (screen, print, web)

### Theme Application
- **Be consistent** - use theme colors and fonts throughout
- **Follow hierarchy** - headings in heading font, body in body font
- **Use accents sparingly** - accent colors for emphasis, not everywhere
- **Maintain contrast** - ensure text is readable on backgrounds
- **Respect the palette** - don't introduce colors outside the theme

### Custom Themes
- **Gather complete requirements** - understand all constraints before generating
- **Test color combinations** - ensure sufficient contrast for accessibility
- **Verify font pairing** - heading and body fonts should complement
- **Consider versatility** - theme should work across different content types
- **Document the system** - provide color codes and font specifications

### Accessibility Considerations
- **Check contrast ratios** - WCAG AA minimum (4.5:1 for text)
- **Avoid color-only meaning** - use shape, position, or text too
- **Test readability** - especially small text on colored backgrounds
- **Provide alternatives** - if theme has accessibility issues, suggest adjustments

## Common Mistakes to Avoid

- ❌ Skipping the showcase step and describing themes verbally
- ❌ Choosing a theme for the user without their input
- ❌ Mixing colors from different themes
- ❌ Using too many accent colors simultaneously
- ❌ Poor contrast between text and backgrounds
- ❌ Inconsistent font usage (mixing theme fonts with others)
- ❌ Ignoring the mood/message mismatch (e.g., playful theme for serious content)
- ❌ Not testing the theme at intended viewing size/medium

## Advanced Usage

### Theme Customization
After selecting a preset theme, users can request modifications:
- Adjust specific colors while keeping others
- Change one font while maintaining the pairing
- Lighten or darken the overall palette
- Add additional accent colors

### Multi-Artifact Consistency
When creating multiple related artifacts:
- Use the same theme across all pieces
- Maintain consistent hierarchy and spacing
- Apply theme systematically for cohesive brand presence

### Responsive Theme Application
For web artifacts:
- Ensure themes work at different screen sizes
- Adjust font sizes responsively
- Maintain contrast ratios across devices
- Test dark mode variants if needed