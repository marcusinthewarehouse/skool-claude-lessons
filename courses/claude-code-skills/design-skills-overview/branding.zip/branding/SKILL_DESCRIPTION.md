# Branding (Brand Guidelines)

## Overview

The Branding skill provides access to Anthropic's official brand colors, typography, and design standards to ensure visual consistency across all materials. This skill applies professional design standards automatically to any visual work requiring brand compliance.

## Who Should Use This Skill

- **Marketing Teams** creating brand-compliant materials
- **Designers** working on official company presentations and documents
- **Content Creators** producing visual materials for Anthropic
- **Product Teams** ensuring brand consistency in user-facing materials
- **Anyone** creating materials that need to follow official brand guidelines

## Purpose and Use Cases

Use this skill when you need to:
- Apply official Anthropic brand colors to designs
- Use correct brand typography in documents and presentations
- Ensure visual consistency with company design standards
- Create brand-compliant marketing materials
- Follow official color and font specifications

**Keywords that trigger this skill:** brand colors, brand style, brand guidelines, visual formatting, company design standards

## What's Included

### Official Anthropic Brand Colors

**Primary Colors:**
- **Dark:** #141413 (Nearly black - primary text and bold elements)
- **Light:** #faf9f5 (Warm off-white - backgrounds and light elements)

**Accent Colors:**
- **Orange:** #d97757 (Warm, energetic - call-to-action and highlights)
- **Blue:** #6a9bcc (Cool, trustworthy - secondary accents and information)
- **Green:** #788c5d (Natural, balanced - tertiary accents and success states)

### Typography Standards

**Heading Font: Poppins**
- Used for titles, headings, and large text (24pt and above)
- Sans-serif font that's clean, modern, and highly readable
- Provides strong visual hierarchy
- Professional and approachable aesthetic

**Body Font: Lora**
- Used for body text and smaller elements (below 24pt)
- Serif font that's elegant and easy to read
- Excellent for long-form content
- Adds sophistication and warmth

### Smart Font Application Rules

The skill automatically applies typography based on text size:
- **24pt or larger** → Use Poppins (headings)
- **Below 24pt** → Use Lora (body text)
- **Fallbacks:** Arial for Poppins, Georgia for Lora (when brand fonts unavailable)

### Additional Design Elements

**Shape and Accent Colors:**
- Secondary color palette for visual variety
- Complementary colors that maintain brand harmony
- Usage guidance for different contexts

**Visual Consistency:**
- Proper color contrast ratios for accessibility
- Spacing and layout principles
- Brand-compliant design patterns

## How It Works

### Automatic Application

When creating any visual material:

1. **Color Selection:** Automatically applies official Anthropic colors from the approved palette
2. **Typography Assignment:** Intelligently applies Poppins or Lora based on text size
3. **Fallback Handling:** Provides appropriate fallbacks (Arial/Georgia) when needed
4. **Design Standards:** Follows spacing, contrast, and layout principles

### Manual Usage

When you need specific brand elements:

**For Colors:**
- Reference the official hex codes: #141413, #faf9f5, #d97757, #6a9bcc, #788c5d
- Use Dark for primary text and strong elements
- Use Light for backgrounds and negative space
- Use accent colors (Orange, Blue, Green) for highlights and CTAs

**For Typography:**
- Headings/titles (≥24pt): Poppis, fallback Arial
- Body text (<24pt): Lora, fallback Georgia
- Maintain consistent font sizing across similar element types

## Technical Details

### Color Implementation

**Hex Values:**
```
Dark:   #141413
Light:  #faf9f5
Orange: #d97757
Blue:   #6a9bcc
Green:  #788c5d
```

**RGB Values (if needed):**
- Dark: rgb(20, 20, 19)
- Light: rgb(250, 249, 245)
- Orange: rgb(217, 119, 87)
- Blue: rgb(106, 155, 204)
- Green: rgb(120, 140, 93)

### Font Specifications

**Poppins:**
- Type: Sans-serif
- Usage: Headings, titles, large text (≥24pt)
- Fallback: Arial

**Lora:**
- Type: Serif
- Usage: Body text, paragraphs (<24pt)
- Fallback: Georgia

### Accessibility Considerations

- All color combinations meet WCAG contrast requirements
- Typography choices ensure readability across different sizes
- Color-blind friendly palette design
- Scalable and responsive across devices

## Use Cases and Examples

### Presentations
- Slide backgrounds: Light (#faf9f5)
- Slide titles: Poppins with Dark (#141413)
- Body text: Lora with Dark (#141413)
- Accent elements: Orange (#d97757) for CTAs

### Documents
- Page background: Light (#faf9f5)
- Headings: Poppins, Dark color
- Body text: Lora, Dark color
- Highlights: Orange, Blue, or Green accents

### Marketing Materials
- Primary branding: Dark and Orange
- Backgrounds: Light with subtle accents
- Typography hierarchy: Poppins headings, Lora body
- Call-to-action: Orange with sufficient contrast

### Web/Digital Design
- Header text: Poppins
- Paragraph text: Lora
- Buttons: Orange background with Light text
- Links and interactive elements: Blue or Orange

## Best Practices

- **Never deviate from official hex codes** - use the exact values provided
- **Maintain typography hierarchy** - Poppins for emphasis, Lora for readability
- **Use accent colors purposefully** - Orange for CTAs, Blue for information, Green for success
- **Ensure sufficient contrast** - Dark text on Light backgrounds or vice versa
- **Follow the 24pt rule** - automatically determines Poppins vs. Lora
- **Include fallback fonts** - Arial for Poppins, Georgia for Lora
- **Test across devices** - ensure brand consistency on all screen sizes
- **Maintain white space** - Light color provides breathing room
- **Create visual hierarchy** - use color and typography to guide the eye