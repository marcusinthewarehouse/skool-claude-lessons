# Design System (UI Design System Toolkit)

## Overview

The Design System skill provides a comprehensive toolkit for creating and maintaining scalable UI design systems. This skill enables systematic generation of design tokens, component architecture, responsive design calculations, and developer handoff documentation, ensuring visual consistency and efficient design-to-development workflows.

## Who Should Use This Skill

- **Senior UI Designers** building comprehensive design systems
- **Design System Leads** maintaining design token libraries
- **Product Designers** ensuring visual consistency across products
- **Frontend Developers** implementing design systems in code
- **Design Operations Teams** managing design-development collaboration
- **Brand Designers** translating brand guidelines into systematic tokens

## Purpose and Use Cases

Use this skill when you need to:
- Generate complete design token libraries from brand colors
- Create systematic color palettes with semantic naming
- Establish modular typography scales
- Build responsive spacing and layout systems
- Define shadow, animation, and effect tokens
- Document component specifications for developers
- Ensure accessibility compliance across design systems
- Export design tokens in multiple formats (JSON, CSS, SCSS)

**Keywords that trigger this skill:** design tokens, design system, component library, design consistency, spacing system, typography scale, design handoff, design-to-code

## What's Included

### Design Token Generator

**Complete Token Categories:**
- **Color Tokens:** Primary, secondary, semantic colors with tints and shades
- **Typography Tokens:** Font families, sizes, weights, line heights
- **Spacing Tokens:** 8pt grid system with responsive scales
- **Shadow Tokens:** Elevation system with multiple levels
- **Animation Tokens:** Duration, easing, and motion patterns
- **Border Tokens:** Radius, width, and style specifications

**Export Formats:**
- **JSON:** For design tool plugins and documentation
- **CSS Custom Properties:** For web implementations
- **SCSS Variables:** For preprocessor workflows

### Color System Generation

**Automatic Palette Creation:**
- Primary color palette (5 shades from brand color)
- Secondary and accent color variations
- Semantic colors (success, warning, error, info)
- Neutral grayscale palette
- Opacity and transparency scales
- Accessible color combinations with WCAG compliance

**Smart Color Naming:**
- Hierarchical naming convention (primary-500, neutral-100)
- Semantic naming for UI states (success-light, error-dark)
- Consistent naming patterns across color families

### Typography System

**Modular Scale Generation:**
- Base size configuration (typically 16px)
- Scale ratio options (1.125, 1.25, 1.333, 1.5, 1.618)
- Complete type scale from xs to 6xl
- Responsive typography with fluid scales
- Line height calculations for optimal readability

**Font System:**
- Heading font families and weights
- Body font families and weights
- Monospace font for code elements
- Font loading and fallback strategies

### Spacing and Layout

**8pt Grid System:**
- Base spacing unit (8px)
- Complete spacing scale (0.5x to 24x base unit)
- Consistent spacing tokens (4px, 8px, 16px, 24px, 32px, etc.)
- Negative spacing for overlaps
- Responsive spacing modifiers

**Layout Tokens:**
- Container max-widths
- Responsive breakpoints (mobile, tablet, desktop, wide)
- Grid column configurations
- Gutter sizes
- Content area constraints

### Component Architecture

**Component Documentation:**
- Anatomy diagrams showing component parts
- State variations (default, hover, active, disabled, error)
- Size variants (small, medium, large)
- Theme variations (light, dark, high contrast)
- Responsive behavior specifications

**Design Specifications:**
- Spacing and padding values
- Typography usage
- Color application
- Interactive state transitions
- Accessibility requirements

### Accessibility Features

**Built-in Compliance:**
- WCAG 2.1 AA color contrast ratios
- Focus indicator specifications
- Touch target sizing (44x44px minimum)
- Keyboard navigation patterns
- Screen reader considerations
- Motion reduction preferences

**Accessibility Tokens:**
- High contrast color alternatives
- Focus ring styles
- Reduced motion animation sets
- Text size override considerations

## How It Works

### Token Generation Process

**Step 1: Brand Input**
- Provide primary brand color (hex code)
- Select design style (modern, classic, playful)
- Choose export format (JSON, CSS, SCSS)

**Step 2: Automatic Generation**
```bash
python scripts/design_token_generator.py #3b82f6 modern json
```

The script automatically:
1. Generates complete color palette from brand color
2. Creates semantic color tokens
3. Builds typography scale
4. Establishes spacing system
5. Defines shadow and animation tokens
6. Exports in requested format

**Step 3: Token Structure**

Generated tokens follow this hierarchy:
```
design-tokens/
├── colors/
│   ├── primary/
│   ├── secondary/
│   ├── semantic/
│   └── neutral/
├── typography/
│   ├── font-families/
│   ├── font-sizes/
│   ├── font-weights/
│   └── line-heights/
├── spacing/
│   ├── base-unit/
│   └── scale/
├── shadows/
│   └── elevation-levels/
├── animation/
│   ├── duration/
│   └── easing/
└── breakpoints/
```

### Style Options

**Modern Style:**
- Bright, saturated colors
- Clean, sans-serif typography
- Subtle shadows and borders
- Smooth animations
- Wide spacing

**Classic Style:**
- Muted, sophisticated colors
- Serif and traditional fonts
- Pronounced shadows
- Slower, elegant animations
- Moderate spacing

**Playful Style:**
- Vibrant, diverse colors
- Rounded, friendly fonts
- Soft shadows
- Bouncy animations
- Varied spacing

### Implementation Workflow

**For Designers:**
1. Generate tokens from brand colors
2. Import JSON into design tools (Figma, Sketch)
3. Apply tokens to component library
4. Document component usage
5. Share specifications with developers

**For Developers:**
1. Receive exported tokens (CSS/SCSS)
2. Import into codebase
3. Reference tokens in component code
4. Maintain consistency across implementation
5. Update tokens as design evolves

## Technical Details

### Token Format Examples

**JSON Output:**
```json
{
  "color": {
    "primary": {
      "50": "#eff6ff",
      "500": "#3b82f6",
      "900": "#1e3a8a"
    }
  },
  "spacing": {
    "xs": "4px",
    "sm": "8px",
    "md": "16px"
  },
  "typography": {
    "fontSize": {
      "base": "16px",
      "lg": "18px",
      "xl": "20px"
    }
  }
}
```

**CSS Custom Properties:**
```css
:root {
  --color-primary-500: #3b82f6;
  --spacing-md: 16px;
  --font-size-base: 16px;
  --shadow-md: 0 4px 6px rgba(0,0,0,0.1);
}
```

**SCSS Variables:**
```scss
$color-primary-500: #3b82f6;
$spacing-md: 16px;
$font-size-base: 16px;
$shadow-md: 0 4px 6px rgba(0,0,0,0.1);
```

### Color Palette Algorithm

**Shade Generation:**
- Lighter shades (50-400): Increase lightness, decrease saturation
- Base shade (500): Brand color input
- Darker shades (600-900): Decrease lightness, increase saturation
- Maintains visual consistency across palette

**Semantic Color Mapping:**
- Success: Green tones (#10b981)
- Warning: Yellow/amber tones (#f59e0b)
- Error: Red tones (#ef4444)
- Info: Blue tones (#3b82f6)

### Typography Scale Calculation

**Modular Scale Formula:**
```
Font Size = Base Size × (Scale Ratio) ^ Step
```

**Example (Base: 16px, Ratio: 1.25):**
- xs: 12.8px
- sm: 14px
- base: 16px
- lg: 20px
- xl: 25px
- 2xl: 31.25px

### Spacing Scale

**8pt Grid System:**
```
0.5x = 4px   (xs)
1x = 8px     (sm)
2x = 16px    (md)
3x = 24px    (lg)
4x = 32px    (xl)
6x = 48px    (2xl)
8x = 64px    (3xl)
12x = 96px   (4xl)
16x = 128px  (5xl)
24x = 192px  (6xl)
```

### Breakpoint System

**Responsive Breakpoints:**
- Mobile: 320px - 639px
- Tablet: 640px - 1023px
- Desktop: 1024px - 1439px
- Wide: 1440px+

## Use Cases and Examples

### Building a Complete Design System

**Scenario:** Creating a design system for a SaaS product

**Process:**
1. Extract brand color (#6366f1) from brand guidelines
2. Generate tokens: `python scripts/design_token_generator.py #6366f1 modern json`
3. Import JSON into Figma
4. Build component library using tokens
5. Export CSS tokens for development
6. Document component usage patterns
7. Maintain version control for tokens

### Responsive Design Implementation

**Scenario:** Creating responsive spacing system

**Use Tokens:**
```css
.container {
  padding: var(--spacing-md); /* 16px on mobile */
}

@media (min-width: 1024px) {
  .container {
    padding: var(--spacing-xl); /* 32px on desktop */
  }
}
```

### Component Theming

**Scenario:** Button component with design tokens

**Implementation:**
```css
.button {
  padding: var(--spacing-sm) var(--spacing-md);
  font-size: var(--font-size-base);
  font-weight: var(--font-weight-medium);
  border-radius: var(--border-radius-md);
  background-color: var(--color-primary-500);
  color: var(--color-neutral-50);
  box-shadow: var(--shadow-sm);
  transition: all var(--duration-normal) var(--ease-in-out);
}

.button:hover {
  background-color: var(--color-primary-600);
  box-shadow: var(--shadow-md);
}
```

### Dark Mode Implementation

**Scenario:** Creating dark theme variant

**Token Override:**
```css
[data-theme="dark"] {
  --color-background: var(--color-neutral-900);
  --color-text: var(--color-neutral-50);
  --color-border: var(--color-neutral-700);
}
```

### Accessibility-First Design

**Scenario:** Ensuring WCAG AA compliance

**Color Contrast Validation:**
- Text on primary-500 background: Use neutral-50 (AAA contrast)
- Interactive elements: Minimum 44x44px touch targets
- Focus indicators: 2px solid outline with high contrast
- Motion: Respect prefers-reduced-motion

## Best Practices

### Token Naming Conventions

- **Use hierarchical naming:** `color-primary-500`, not `blue-medium`
- **Be semantic for UI states:** `color-success`, not `color-green`
- **Maintain consistency:** Same pattern across all token categories
- **Avoid presentational names:** `spacing-md`, not `spacing-16px`
- **Use T-shirt sizing:** xs, sm, md, lg, xl, 2xl...

### Design System Governance

- **Version control tokens:** Track changes in Git
- **Document breaking changes:** Communicate token updates
- **Deprecation strategy:** Phase out old tokens gradually
- **Regular audits:** Remove unused tokens quarterly
- **Stakeholder review:** Get approval before major changes

### Component Development

- **Always use tokens:** Never hard-code values
- **Build composable components:** Combine tokens systematically
- **Test across themes:** Validate light, dark, high contrast
- **Accessibility testing:** Automated and manual validation
- **Document variants:** Show all states and sizes

### Developer Handoff

- **Provide token documentation:** Clear usage guidelines
- **Include code examples:** Show implementation patterns
- **Share design files:** Figma/Sketch with applied tokens
- **Establish sync process:** Regular token updates
- **Create living style guide:** Automated documentation

### Scaling the System

- **Start small:** Core tokens first, expand gradually
- **Measure adoption:** Track token usage in codebase
- **Gather feedback:** Regular designer/developer sync
- **Automate validation:** Lint rules for token usage
- **Training program:** Onboard new team members

### Maintenance Workflow

1. **Quarterly token review:** Evaluate usage and needs
2. **Update based on feedback:** Designer and developer input
3. **Test thoroughly:** Visual regression testing
4. **Version and release:** Semantic versioning
5. **Communicate changes:** Release notes and migration guides
6. **Monitor adoption:** Track implementation progress

## Integration Points

This skill integrates with:
- **Design Tools:** Figma, Sketch, Adobe XD (via JSON import)
- **Build Tools:** Webpack, Vite, Rollup (token preprocessing)
- **CSS Frameworks:** Tailwind CSS, Bootstrap (token mapping)
- **Documentation:** Storybook, Docusaurus (living style guides)
- **Version Control:** Git (token versioning)
- **CI/CD:** Automated token validation and deployment

## Common Challenges and Solutions

### Challenge: Token Proliferation
**Solution:** Regular audits, deprecation strategy, clear naming guidelines

### Challenge: Cross-Platform Consistency
**Solution:** Single source of truth, automated distribution, platform-specific transforms

### Challenge: Designer-Developer Sync
**Solution:** Automated token sync, shared documentation, regular meetings

### Challenge: Legacy Code Migration
**Solution:** Gradual migration plan, parallel systems, automated linting

### Challenge: Performance Concerns
**Solution:** Token tree-shaking, CSS variable optimization, lazy loading
