# Agile Product Owner (Agile PO Toolkit)

## Overview

The Agile Product Owner skill provides a complete toolkit for excelling at backlog management and sprint execution in Agile/Scrum environments. This skill enables generation of INVEST-compliant user stories, automatic acceptance criteria creation, sprint capacity planning, backlog prioritization, and velocity tracking, ensuring effective collaboration between product and engineering teams.

## Who Should Use This Skill

- **Senior Product Owners** leading Agile/Scrum teams
- **Product Owners** managing sprint backlogs and planning
- **Scrum Masters** facilitating agile ceremonies and processes
- **Agile Coaches** establishing best practices and standards
- **Product Managers** working in agile environments
- **Technical Product Managers** bridging product and engineering
- **Team Leads** coordinating sprint delivery

## Purpose and Use Cases

Use this skill when you need to:
- Generate INVEST-compliant user stories from epics
- Create comprehensive acceptance criteria automatically
- Plan sprint capacity with team velocity
- Break down large epics into deliverable stories
- Prioritize product backlog systematically
- Track team velocity and forecast delivery
- Validate story quality against INVEST criteria
- Estimate story points systematically
- Facilitate sprint planning meetings
- Manage backlog refinement sessions

**Keywords that trigger this skill:** user stories, sprint planning, backlog management, INVEST criteria, acceptance criteria, story points, agile ceremonies, velocity tracking, epic breakdown, sprint capacity

## What's Included

### User Story Generator

**Automatic Story Generation:**
- Breaks down epics into user stories
- Generates INVEST-compliant stories
- Creates detailed acceptance criteria
- Assigns story point estimates
- Prioritizes stories by value
- Validates against INVEST framework

**INVEST Validation:**
- **Independent:** Stories can be developed separately
- **Negotiable:** Details can be discussed and refined
- **Valuable:** Delivers clear user value
- **Estimable:** Team can estimate effort
- **Small:** Can complete in one sprint
- **Testable:** Clear acceptance criteria

**Story Components:**
- User story statement (As a... I want... So that...)
- Detailed acceptance criteria
- Story point estimate (Fibonacci scale)
- Priority level (Must Have, Should Have, Could Have)
- Dependencies on other stories
- Technical considerations

### Sprint Planning Tool

**Capacity Planning:**
- Team velocity input
- Available capacity per sprint
- Automatic story fitting
- Dependency management
- Risk buffer allocation

**Planning Features:**
- Velocity-based forecasting
- Sprint goal definition
- Story commitment validation
- Capacity vs. commitment analysis
- Multi-sprint roadmap projection

**Sprint Outputs:**
- Committed stories list
- Total story points
- Capacity utilization
- Risk assessment
- Dependencies and blockers

### Backlog Management Framework

**Prioritization Methods:**
- MoSCoW (Must/Should/Could/Won't)
- Value vs. Effort matrix
- Business value ranking
- Risk-adjusted prioritization
- Dependency-aware ordering

**Backlog Grooming:**
- Story refinement guidelines
- Definition of Ready criteria
- Estimation poker facilitation
- Story splitting techniques
- Technical debt management

**Backlog Health Metrics:**
- Stories ready for sprint (2 sprints ahead)
- Story point distribution
- Epic completion tracking
- Velocity trend analysis
- Commitment accuracy

### Velocity Tracking System

**Metrics Tracked:**
- Planned vs. actual velocity
- Story point completion rate
- Sprint commitment accuracy
- Average velocity (rolling 3 sprints)
- Velocity trend (improving/declining)

**Forecasting:**
- Epic completion timeline
- Release planning projections
- Capacity planning for quarters
- Risk-adjusted estimates
- Confidence intervals

### Agile Ceremony Support

**Sprint Planning:**
- Story presentation templates
- Acceptance criteria review
- Estimation facilitation
- Capacity calculation
- Sprint goal definition

**Daily Standup:**
- Progress tracking
- Blocker identification
- Sprint burndown monitoring

**Sprint Review:**
- Demo script templates
- Stakeholder feedback capture
- Velocity reporting
- Sprint retrospective metrics

**Sprint Retrospective:**
- Team health assessment
- Process improvement tracking
- Action item management
- Velocity analysis

## How It Works

### User Story Generation Workflow

**Step 1: Define Epic**
Create epic description:
```
Epic: Enhanced User Profile Management

Users need comprehensive profile customization to express
their identity and preferences. This includes profile photos,
bio, social links, privacy settings, and display preferences.
```

**Step 2: Generate Stories**
```bash
# Interactive story generation
python scripts/user_story_generator.py

# Generates stories from epic
# Prompts for epic details
# Creates INVEST-compliant stories
```

**Step 3: Review Generated Stories**
```
USER STORY 1: Profile Photo Upload
===========================================
As a registered user
I want to upload a profile photo
So that I can personalize my account and be recognized by others

ACCEPTANCE CRITERIA:
✓ User can click on profile avatar to upload photo
✓ Supported formats: JPG, PNG, GIF (max 5MB)
✓ Photo is automatically cropped to square aspect ratio
✓ Preview shown before final upload
✓ Uploaded photo displays across all user touchpoints
✓ User can delete and replace photo anytime

STORY POINTS: 5
PRIORITY: Must Have
DEPENDENCIES: None

INVEST VALIDATION:
✓ Independent: Can be developed standalone
✓ Negotiable: Implementation details flexible
✓ Valuable: Clear user benefit (personalization)
✓ Estimable: Team can estimate (5 points)
✓ Small: Completable in one sprint
✓ Testable: Clear acceptance criteria

---

USER STORY 2: Bio and Personal Information
===========================================
As a registered user
I want to add a bio and personal details
So that I can share information about myself with the community

ACCEPTANCE CRITERIA:
✓ Bio text field supports up to 500 characters
✓ Character count displayed while typing
✓ Support for line breaks and basic formatting
✓ Personal fields: name, location, website, social links
✓ All fields optional except display name
✓ Changes saved with "Update Profile" button
✓ Success confirmation shown after save

STORY POINTS: 3
PRIORITY: Must Have
DEPENDENCIES: None

INVEST VALIDATION:
✓ Independent: Can be developed standalone
✓ Negotiable: Field limits and formats flexible
✓ Valuable: User self-expression
✓ Estimable: Standard CRUD operation
✓ Small: Completable in one sprint
✓ Testable: Clear field requirements

---

USER STORY 3: Privacy Settings
===========================================
As a registered user
I want to control who can view my profile information
So that I can maintain my desired level of privacy

ACCEPTANCE CRITERIA:
✓ Toggle controls for profile visibility (public/private)
✓ Granular settings for profile photo, bio, email
✓ Default settings explained clearly
✓ Changes applied immediately
✓ Privacy settings accessible from profile page
✓ Clear explanation of what each setting controls

STORY POINTS: 8
PRIORITY: Should Have
DEPENDENCIES: Stories 1, 2 (must exist before adding privacy)

INVEST VALIDATION:
✓ Independent: Can develop after dependent stories
✓ Negotiable: Granularity level flexible
✓ Valuable: User privacy and control
✓ Estimable: Moderate complexity (8 points)
✓ Small: Can complete in one sprint (borderline)
⚠ Testable: Requires comprehensive test cases

RECOMMENDATION: Consider splitting into:
- Story 3a: Basic privacy toggle (5 points)
- Story 3b: Granular privacy controls (3 points)
```

### Sprint Planning Workflow

**Step 1: Gather Team Data**
- Team capacity: 40 story points per sprint
- Current velocity: 35-40 points (last 3 sprints)
- Available developers: 5
- Sprint duration: 2 weeks

**Step 2: Run Sprint Planner**
```bash
# Plan sprint with capacity
python scripts/user_story_generator.py sprint 40

# Alternatively, use average velocity
python scripts/user_story_generator.py sprint 38
```

**Step 3: Review Sprint Plan**
```
SPRINT PLANNING RECOMMENDATION
================================

Sprint Capacity: 40 story points
Recommended Commitment: 36 points (90% of capacity)
Buffer: 4 points (10% for unknowns)

COMMITTED STORIES:
==================

HIGH PRIORITY (Must Have):
1. Profile Photo Upload - 5 points
2. Bio and Personal Information - 3 points
3. Basic Privacy Toggle (3a) - 5 points
4. Social Links Integration - 3 points
5. Display Name Settings - 2 points

MEDIUM PRIORITY (Should Have):
6. Profile Preview Mode - 8 points
7. Profile URL Customization - 5 points

STRETCH GOALS (Could Have):
8. Profile Themes - 5 points

Total Committed: 36 points
Stretch Goal: 41 points (if velocity strong)

SPRINT GOAL:
"Enable users to create personalized profiles with photos,
bios, and basic privacy controls"

RISKS:
⚠ Privacy toggle (Story 3a) is new territory - may take longer
⚠ Profile preview depends on all other stories completing
✓ Social links integration well understood

DEPENDENCIES:
→ Stories 1-5 are independent
→ Story 6 depends on Stories 1-4
→ All stories blocked by user auth (completed)

RECOMMENDATIONS:
• Start with Stories 1-2 (independent, must-have)
• Prioritize Story 3a early (new complexity)
• Keep Story 6 flexible (remove if velocity low)
• Monitor progress daily (complex sprint)
```

**Step 4: Sprint Execution**
- Daily standup progress tracking
- Update story status (To Do → In Progress → Done)
- Track burndown chart
- Manage scope changes
- Adjust if velocity differs

### Backlog Refinement Process

**Weekly Refinement Session (1 hour):**

**Agenda:**
1. Review upcoming stories (15 min)
2. Break down large stories (20 min)
3. Estimate refined stories (15 min)
4. Prioritize backlog (10 min)

**Definition of Ready Checklist:**
```
Story is ready for sprint if:
✓ Written in user story format
✓ Has clear acceptance criteria
✓ Estimated by team (story points)
✓ Dependencies identified
✓ No blocking questions
✓ Stakeholder acceptance criteria confirmed
✓ Fits in one sprint (≤13 points)
✓ Team understands business value
```

**Story Splitting Techniques:**

Large story (13+ points) splits:
```
Original: Advanced Search (21 points)

Split by:
→ Story A: Basic keyword search (8 points)
→ Story B: Filter by category (5 points)
→ Story C: Sort results (3 points)
→ Story D: Save search preferences (5 points)
```

### Velocity Tracking and Forecasting

**Track Velocity Per Sprint:**
```
Sprint 1: Planned 40 → Completed 35 (88%)
Sprint 2: Planned 38 → Completed 38 (100%)
Sprint 3: Planned 40 → Completed 32 (80%)
Sprint 4: Planned 36 → Completed 36 (100%)
Sprint 5: Planned 38 → Completed 40 (105%)

Average Velocity (last 3): 36 points
Trend: Stable with occasional variance
Commitment Accuracy: 91% (high)
```

**Epic Forecasting:**
```
Epic: Enhanced Profiles (Total: 120 points)
Completed: 45 points (38%)
Remaining: 75 points

At average velocity of 36 points/sprint:
Estimated completion: 2-3 more sprints
Confidence: 80% (based on stable velocity)

Conservative estimate: 3 sprints
Optimistic estimate: 2 sprints
Realistic target: Sprint 8 (end of month)
```

## Technical Details

### INVEST Criteria Validation

**Independent:**
- Story can be developed in any order
- Minimal dependencies on other stories
- Can deploy independently if needed

**Negotiable:**
- Acceptance criteria not set in stone
- Implementation details flexible
- Room for technical creativity

**Valuable:**
- Clear user or business value
- User story format explains value
- Stakeholder can prioritize importance

**Estimable:**
- Team has enough information to estimate
- Complexity is understood
- Unknowns are minimized

**Small:**
- Completable in one sprint
- Generally ≤13 story points
- Can be tested and deployed quickly

**Testable:**
- Clear acceptance criteria
- Observable outcomes
- Can be validated by QA

### Story Point Estimation

**Fibonacci Scale:**
```
1 point: Trivial change (1-2 hours)
2 points: Simple feature (half day)
3 points: Moderate feature (1 day)
5 points: Standard feature (2-3 days)
8 points: Complex feature (1 week)
13 points: Very complex (at sprint limit)
21+ points: Epic - must be split
```

**Estimation Technique: Planning Poker**
1. Product Owner reads story
2. Team asks clarifying questions
3. Each member selects card (1, 2, 3, 5, 8, 13)
4. All reveal simultaneously
5. Discuss differences (highest and lowest explain)
6. Re-estimate until consensus
7. Record final estimate

**Velocity Calculation:**
```
Sprint Velocity = Sum of completed story points

Average Velocity = Sum of last 3 sprints / 3

Example:
Sprint 10: 38 points
Sprint 11: 35 points
Sprint 12: 40 points
Average: (38 + 35 + 40) / 3 = 37.67 ≈ 38 points
```

### Sprint Capacity Planning

**Capacity Calculation:**
```
Team Capacity =
  (Number of developers × Hours per day × Sprint days)
  - (PTO + Meetings + Overhead)

Example:
5 developers × 6 productive hours × 10 days = 300 hours
- 40 hours PTO
- 30 hours meetings (standups, planning, retro)
- 30 hours overhead (support, email, etc.)
= 200 hours available

Convert to story points (5 hours per point):
200 hours / 5 = 40 story points capacity
```

**Commitment Strategy:**
```
Conservative: 80% of capacity (32 points)
Moderate: 90% of capacity (36 points)
Aggressive: 100% of capacity (40 points)

Recommended: 90% with 10% buffer for:
- Bug fixes
- Production issues
- Scope creep
- Estimation errors
```

## Use Cases and Examples

### Breaking Down User Registration Epic

**Epic:** User Registration and Onboarding (55 points)

**Generated Stories:**

**Story 1: Basic Registration Form (5 points)**
```
As a new visitor
I want to create an account with email and password
So that I can access the platform

Acceptance Criteria:
✓ Email field with validation
✓ Password field with strength indicator
✓ Confirm password field with matching validation
✓ Terms of service checkbox
✓ "Create Account" button
✓ Email verification sent upon registration
✓ Error handling for duplicate emails
```

**Story 2: Email Verification (3 points)**
```
As a new user
I want to verify my email address
So that the system confirms I own the email

Acceptance Criteria:
✓ Verification email sent within 1 minute
✓ Unique verification link (expires in 24h)
✓ Clicking link marks email as verified
✓ Confirmation message shown
✓ Redirect to onboarding flow
✓ Resend verification option
```

**Story 3: Social Login Integration (8 points)**
```
As a new visitor
I want to sign up using Google or GitHub
So that I can skip manual registration

Acceptance Criteria:
✓ "Continue with Google" button
✓ "Continue with GitHub" button
✓ OAuth flow integration
✓ Automatic email verification (trusted provider)
✓ Profile data pre-populated from social account
✓ Fallback to email if social login fails
```

**Story 4: Onboarding Welcome Flow (5 points)**
```
As a newly registered user
I want to see a welcome tutorial
So that I understand how to use the platform

Acceptance Criteria:
✓ Welcome screen with platform overview
✓ 3-step guided tour of key features
✓ Skip option available
✓ Progress indicator shown
✓ Completion redirects to dashboard
✓ Tracked for analytics
```

**Story 5: Profile Setup Wizard (8 points)**
```
As a new user completing onboarding
I want to set up my profile
So that I can personalize my account

Acceptance Criteria:
✓ Upload profile photo (optional)
✓ Enter display name (required)
✓ Add bio (optional, 250 chars)
✓ Select interests/tags (3-5 required)
✓ Save and continue button
✓ Progress saved between steps
```

**Total: 29 points (Story 6-8 would add remaining 26 points)**

### Planning Sprint 15

**Context:**
- Team: 6 developers
- Average velocity: 42 points
- Sprint duration: 2 weeks
- Epic in progress: Enhanced Profiles (75 points remaining)

**Backlog (Prioritized):**
```
MUST HAVE:
1. Profile Photo Upload - 5 points ✓ Ready
2. Bio Editor - 3 points ✓ Ready
3. Privacy Settings - 8 points ✓ Ready
4. Social Links - 3 points ✓ Ready

SHOULD HAVE:
5. Profile Themes - 8 points ✓ Ready
6. Custom URL - 5 points ⚠ Needs refinement
7. Activity Feed - 13 points ⚠ Needs splitting

COULD HAVE:
8. Profile Analytics - 8 points ✓ Ready
9. Badge System - 13 points ⚠ Needs splitting
```

**Sprint Plan:**
```
SPRINT 15 COMMITMENT (42 point capacity)
========================================

COMMITTED (38 points, 90% capacity):
✓ Profile Photo Upload - 5 points
✓ Bio Editor - 3 points
✓ Privacy Settings - 8 points
✓ Social Links - 3 points
✓ Profile Themes - 8 points
✓ Custom URL - 5 points (after quick refinement)
✓ Profile Analytics - 6 points (reduced scope)

BUFFER (4 points):
- Production bug fixes
- Support escalations
- Estimation uncertainty

DEFERRED TO SPRINT 16:
- Activity Feed (needs splitting)
- Badge System (needs splitting)

SPRINT GOAL:
"Complete core profile customization features with
photo, bio, privacy, and theming capabilities"

RISKS:
⚠ Privacy Settings (8pt) is largest story - start early
⚠ Custom URL needs quick refinement (30 min)
✓ Team is familiar with similar features

DEPENDENCIES:
→ All stories independent
→ No external team dependencies
→ Infrastructure ready (confirmed)
```

### Velocity Tracking and Adjustment

**Historical Data:**
```
Sprint 10: 38 points planned, 38 completed (100%)
Sprint 11: 42 points planned, 35 completed (83%) [Holiday week]
Sprint 12: 40 points planned, 40 completed (100%)
Sprint 13: 42 points planned, 44 completed (105%) [Unusually high]
Sprint 14: 42 points planned, 38 completed (90%) [Production issue]

Average (last 3 sprints): 40.67 points
Trend: Stable around 40 points
Commitment accuracy: 95% ± 5 points
```

**Forecasting Epic Completion:**
```
Epic: Search & Discovery (150 points total)
Completed: 70 points (47%)
Remaining: 80 points

Using average velocity: 40 points/sprint
Estimated sprints remaining: 80 / 40 = 2 sprints

Conservative (35 points): 80 / 35 = 2.3 sprints → 3 sprints
Optimistic (44 points): 80 / 44 = 1.8 sprints → 2 sprints
Realistic (40 points): 80 / 40 = 2 sprints

Forecast: Complete by end of Sprint 16 (2 sprints)
Confidence: 85% (based on stable velocity)
```

## Best Practices

### Writing Effective User Stories

**Do:**
- Use consistent format: "As a [user], I want [goal], So that [benefit]"
- Focus on user value, not implementation
- Keep stories independent when possible
- Include clear acceptance criteria (3-7 items)
- Size stories to fit in one sprint
- Validate stories against INVEST criteria

**Don't:**
- Write technical tasks as user stories
- Skip the "So that" (value) portion
- Create dependencies between stories unnecessarily
- Write acceptance criteria as implementation steps
- Mix multiple features in one story
- Forget to specify edge cases

**Good Example:**
```
As a team admin
I want to bulk invite team members via CSV upload
So that I can onboard large teams efficiently

Acceptance Criteria:
✓ Upload CSV with email, name, role columns
✓ Preview shows first 10 rows before import
✓ Validation checks for duplicate emails
✓ Progress indicator during processing
✓ Success summary shows invited vs. failed
✓ Error report downloadable for failed invites
```

**Bad Example:**
```
As a developer
I want to implement CSV parsing
So that users can upload files

Acceptance Criteria:
✓ Use Papa Parse library
✓ Add CSV endpoint to API
✓ Update database schema
```
*(This is a technical task, not a user story)*

### Sprint Planning Best Practices

**Do:**
- Commit to 85-90% of velocity (leave buffer)
- Start sprint with clear sprint goal
- Ensure all committed stories meet Definition of Ready
- Identify dependencies and blockers upfront
- Get team consensus on estimates
- Plan for some slack time

**Don't:**
- Overcommit to 100%+ of capacity
- Add stories mid-sprint without removing others
- Skip refinement and estimate during planning
- Ignore team members' PTO or commitments
- Let product owner dictate estimates
- Plan for perfect sprint (things always come up)

### Backlog Management

**Healthy Backlog:**
- Top 2 sprints fully refined and ready
- Next 2 sprints partially refined (epics broken down)
- Future items as epics or rough stories
- Regular grooming sessions (weekly)
- Clear prioritization (MoSCoW)
- Size distribution: mostly 3-8 point stories

**Unhealthy Backlog:**
- No stories ready for next sprint
- All stories 13+ points (not split)
- No prioritization or random order
- Hundreds of unrefined items
- No grooming for months
- Technical debt buried at bottom

### Agile Ceremony Facilitation

**Sprint Planning (2 hours for 2-week sprint):**
- Part 1: What (1 hour) - Select stories
- Part 2: How (1 hour) - Break down approach
- Output: Sprint goal + committed stories

**Daily Standup (15 minutes):**
- What did you complete yesterday?
- What will you work on today?
- Any blockers or impediments?
- Update board in real-time

**Sprint Review (1 hour):**
- Demo completed stories
- Gather stakeholder feedback
- Review velocity and metrics
- Accept or reject stories

**Sprint Retrospective (1 hour):**
- What went well?
- What could improve?
- Action items for next sprint
- Review previous actions

### Estimation Guidelines

**Relative Sizing:**
- Pick a reference story (3 or 5 points)
- Estimate others relative to reference
- Focus on effort, not time
- Include all work (dev, test, review, deploy)
- Account for unknowns with higher estimate

**Re-estimation:**
- If story estimate is way off, retrospect why
- Adjust future similar stories based on learning
- Don't re-estimate completed stories
- Use estimation errors to improve process

## Integration Points

This skill integrates with:
- **Agile Tools:** Jira, Azure DevOps, Rally, VersionOne
- **Sprint Boards:** Trello, Asana, Monday.com
- **Planning Tools:** Planning Poker apps, Scrum Poker
- **Analytics:** Jira Reports, ActionableAgile, Velocity charts
- **Communication:** Slack, Microsoft Teams (sprint updates)
- **Documentation:** Confluence, Notion (sprint goals, retros)

## Common Challenges and Solutions

### Challenge: Stories Too Large
**Solution:** Apply story splitting patterns (workflow steps, business rules, CRUD operations, acceptance criteria), aim for 3-8 points, use Definition of Ready

### Challenge: Velocity Widely Varies
**Solution:** Review estimation accuracy, check for external interruptions, stabilize team composition, refine stories better, track unplanned work

### Challenge: Stories Carry Over Sprints
**Solution:** Improve estimation, check Definition of Ready, split stories smaller, identify blockers earlier, adjust capacity planning

### Challenge: Team Disagrees on Estimates
**Solution:** Use planning poker for discussion, identify knowledge gaps, break down story further, defer if too many unknowns, spike if very uncertain

### Challenge: Product Owner Not Available
**Solution:** Set regular availability hours, async communication for questions, empower proxy (senior PM), batch questions, improve story quality

### Challenge: Technical Debt Growing
**Solution:** Allocate 20% capacity to tech debt, make tech debt visible in backlog, tie to user impact, include in sprint goals, track and report
