# Product Manager Toolkit (PM Toolkit)

## Overview

The Product Manager Toolkit provides comprehensive tools and frameworks for modern product management, covering the entire product lifecycle from discovery to delivery. This skill includes RICE prioritization, customer interview analysis, PRD templates, discovery frameworks, and go-to-market strategies, enabling product managers to make data-driven decisions and effectively communicate product strategy.

## Who Should Use This Skill

- **Product Managers** managing product discovery and delivery
- **Senior Product Managers** leading strategic product initiatives
- **Associate Product Managers** learning core PM frameworks
- **Technical Product Managers** bridging product and engineering
- **Product Owners** prioritizing backlogs and features
- **Growth Product Managers** optimizing acquisition and retention
- **Product Leaders** establishing PM practices and standards

## Purpose and Use Cases

Use this skill when you need to:
- Prioritize features using RICE framework
- Analyze customer interviews for insights
- Create comprehensive Product Requirements Documents
- Conduct product discovery research
- Synthesize user feedback and pain points
- Build quarterly roadmaps with capacity planning
- Extract themes from customer conversations
- Generate go-to-market strategies
- Document product specifications
- Make data-driven prioritization decisions

**Keywords that trigger this skill:** RICE prioritization, feature prioritization, customer interviews, PRD, product requirements, discovery, user research synthesis, roadmap planning, product documentation

## What's Included

### RICE Prioritization Framework

**Advanced RICE Implementation:**
- Complete RICE score calculation
- Portfolio balance analysis (quick wins vs. big bets)
- Quarterly roadmap generation
- Team capacity planning
- Multiple output formats (text, JSON, CSV)
- Sample data generation for learning

**RICE Components:**
- **Reach:** Number of users/customers affected per quarter
- **Impact:** Massive (3x), High (2x), Medium (1x), Low (0.5x), Minimal (0.25x)
- **Confidence:** High (100%), Medium (80%), Low (50%)
- **Effort:** Person-months (XL/L/M/S/XS)

**Formula:**
```
RICE Score = (Reach × Impact × Confidence) / Effort
```

**Portfolio Analysis:**
- Quick Wins: High value, low effort
- Big Bets: High value, high effort
- Fill-Ins: Low value, low effort
- Time Sinks: Low value, high effort (avoid)

**Capacity Planning:**
- Quarterly team capacity input (person-months)
- Automatic roadmap fitting
- Effort distribution analysis
- Dependency considerations

### Customer Interview Analyzer

**NLP-Based Analysis:**
- Pain point extraction with severity assessment
- Feature request identification and classification
- Jobs-to-be-Done pattern recognition
- Sentiment analysis
- Theme extraction across interviews
- Competitor mentions tracking
- Key quotes identification

**Analysis Outputs:**
- Categorized pain points (critical, high, medium, low)
- Prioritized feature requests
- Emotional sentiment scores
- Common themes and patterns
- Actionable insights
- Supporting quotes for each finding

**Use Cases:**
- Post-interview synthesis
- Multi-interview pattern detection
- Stakeholder reporting
- Product discovery validation
- Roadmap justification

### PRD Templates

**Multiple Template Formats:**

**1. Standard PRD Template**
- Comprehensive 11-section format
- Best for major features (6-8 weeks)
- Includes technical specifications
- Detailed user stories and acceptance criteria
- Risk assessment and mitigation

**2. One-Page PRD**
- Concise format for quick alignment
- Focus on problem/solution/metrics
- Good for smaller features (2-4 weeks)
- Rapid stakeholder review

**3. Agile Epic Template**
- Sprint-based delivery focus
- User story mapping
- Acceptance criteria emphasis
- Iteration planning

**4. Feature Brief**
- Lightweight exploration document
- Hypothesis-driven approach
- Pre-PRD discovery phase
- Rapid experimentation

**Common Sections:**
- Problem statement
- Target users
- Success metrics
- Solution overview
- User stories
- Out of scope
- Technical considerations
- Dependencies
- Timeline and milestones

### Discovery Frameworks

**Customer Interview Guide:**
- Context questions (5 min)
- Problem exploration (15 min)
- Solution validation (10 min)
- Wrap-up and follow-through (5 min)

**Hypothesis Template:**
```
We believe that [building this feature]
For [these users]
Will [achieve this outcome]
We'll know we're right when [metric]
```

**Opportunity Solution Tree:**
```
Desired Outcome
├── Opportunity 1
│   ├── Solution A
│   ├── Solution B
│   └── Experiments
└── Opportunity 2
    ├── Solution C
    └── Solution D
```

### Prioritization Frameworks

**RICE Framework** (included as script)
**MoSCoW Method:**
- Must Have: Critical for launch
- Should Have: Important but not critical
- Could Have: Nice to have
- Won't Have: Out of scope

**Value vs. Effort Matrix:**
```
         Low Effort    High Effort

High     QUICK WINS    BIG BETS
Value    [Do First]    [Strategic]

Low      FILL-INS      TIME SINKS
Value    [Maybe]       [Avoid]
```

**Kano Model:**
- Basic expectations (must-haves)
- Performance features (more is better)
- Delighters (unexpected wow factors)

### Metrics and Analytics Frameworks

**North Star Metric Framework:**
1. Identify core value to users
2. Make it measurable and trackable
3. Ensure it's actionable by team
4. Verify it's a leading business indicator

**Funnel Analysis Template:**
```
Acquisition → Activation → Retention → Revenue → Referral

Key Metrics:
- Conversion rate at each step
- Drop-off points
- Time between steps
- Cohort variations
```

**Feature Success Metrics:**
- Adoption: % of users using feature
- Frequency: Usage per user per period
- Depth: % of feature capability used
- Retention: Continued usage over time
- Satisfaction: NPS/CSAT for feature

## How It Works

### RICE Prioritization Workflow

**Step 1: Gather Features**
Create CSV file with features:
```csv
name,reach,impact,confidence,effort
User Dashboard,5000,high,high,m
Mobile App,10000,massive,medium,xl
Export Feature,2000,medium,high,s
Search Improvements,8000,high,medium,l
```

**Step 2: Run Prioritization**
```bash
# Basic prioritization
python scripts/rice_prioritizer.py features.csv

# With team capacity (15 person-months/quarter)
python scripts/rice_prioritizer.py features.csv --capacity 15

# Output as JSON
python scripts/rice_prioritizer.py features.csv --output json
```

**Step 3: Review Output**
```
RICE PRIORITIZATION RESULTS
============================

Ranked Features:
1. Export Feature (Score: 266.67)
   Reach: 2000 | Impact: 2x | Confidence: 100% | Effort: 1.5 PM
   Category: Quick Win

2. User Dashboard (Score: 166.67)
   Reach: 5000 | Impact: 2x | Confidence: 100% | Effort: 3 PM
   Category: Big Bet

3. Search Improvements (Score: 106.67)
   Reach: 8000 | Impact: 2x | Confidence: 80% | Effort: 6 PM
   Category: Big Bet

PORTFOLIO ANALYSIS
==================
Quick Wins: 1 features (33%)
Big Bets: 2 features (67%)
Fill-Ins: 0 features (0%)
Time Sinks: 0 features (0%)

QUARTERLY ROADMAP (15 PM capacity)
===================================
Q1: Export Feature (1.5 PM), User Dashboard (3 PM)
Remaining capacity: 10.5 PM
```

**Step 4: Adjust and Refine**
- Review portfolio balance
- Consider strategic fit
- Account for dependencies
- Validate with stakeholders
- Adjust roadmap quarterly

### Customer Interview Analysis Workflow

**Step 1: Conduct Interview**
- Use semi-structured interview guide
- Record session (with permission)
- Take detailed notes
- Focus on problems, not solutions

**Step 2: Transcribe Interview**
Create text file with interview transcript:
```
Interviewer: Tell me about the last time you used our product.

Participant: I tried to export my data last week and it took forever.
The interface is really confusing and I couldn't figure out which format
to use. I ended up just copying and pasting everything manually. It's
frustrating because I need to do this every month.

Interviewer: What would make that easier?
...
```

**Step 3: Run Analysis**
```bash
# Analyze single interview
python scripts/customer_interview_analyzer.py interview.txt

# Output as JSON for aggregation
python scripts/customer_interview_analyzer.py interview.txt json
```

**Step 4: Review Insights**
```
CUSTOMER INTERVIEW ANALYSIS
============================

PAIN POINTS:
[CRITICAL] Data export is slow and confusing
  - Frequency: Monthly
  - Workaround: Manual copy-paste
  - Impact: High frustration, time waste

[HIGH] Format selection unclear
  - Multiple formats confusing
  - No guidance on which to choose

FEATURE REQUESTS:
[HIGH PRIORITY] Simplified export interface
  - Direct correlation to critical pain point
  - Mentioned 3 times in interview

JOBS TO BE DONE:
- Export data for monthly reporting
- Share data with external stakeholders

SENTIMENT: Mostly Negative (-0.6)
- Frustration around current export
- Satisfaction with core features

KEY QUOTES:
"I ended up just copying and pasting everything manually"
"It's frustrating because I need to do this every month"

THEMES:
- Usability issues
- Manual workarounds
- Time efficiency concerns
```

**Step 5: Synthesize Multiple Interviews**
- Aggregate findings across interviews
- Identify common patterns
- Rank pain points by frequency
- Prioritize feature requests
- Map to product opportunities

### PRD Development Process

**Step 1: Choose Template**
Based on feature scope:
- **Standard PRD:** Complex features (6-8 weeks)
- **One-Page PRD:** Simple features (2-4 weeks)
- **Feature Brief:** Exploration phase (1 week)
- **Agile Epic:** Sprint-based delivery

**Step 2: Discovery Work**
- Customer interviews
- Analytics review
- Competitive analysis
- Technical feasibility assessment

**Step 3: Draft PRD**
Use template from `references/prd_templates.md`:
```markdown
# Feature Name: Smart Export

## Problem Statement
Users struggle with data export, spending 30+ minutes monthly
on manual workarounds due to confusing interface and slow processing.

## Success Metrics
- Reduce export time from 30min to 2min
- Increase export usage by 50%
- Improve export satisfaction score from 3/10 to 8/10

## Target Users
- Enterprise customers exporting monthly reports
- Team admins sharing data externally
- Power users with regular export needs

## Solution Overview
Streamlined export interface with:
- Smart format recommendations
- Background processing
- Progress indicators
- Export templates

## Out of Scope (V1)
- Scheduled/automated exports
- Custom export formats
- API-based export
```

**Step 4: Stakeholder Review**
- Engineering: Technical feasibility
- Design: User experience review
- Sales: Customer validation
- Support: Operational impact

**Step 5: Finalize and Share**
- Incorporate feedback
- Version control in product tool
- Share with broader team
- Use as single source of truth

## Technical Details

### RICE Calculation Details

**Impact Multipliers:**
```
Massive: 3.0x
High: 2.0x
Medium: 1.0x
Low: 0.5x
Minimal: 0.25x
```

**Confidence Percentages:**
```
High: 100%
Medium: 80%
Low: 50%
```

**Effort Estimates (Person-Months):**
```
XS: 0.5 PM
S: 1.5 PM
M: 3 PM
L: 6 PM
XL: 12 PM
```

**Portfolio Categorization:**
```
Quick Win: RICE > 100 AND Effort ≤ 3 PM
Big Bet: RICE > 100 AND Effort > 3 PM
Fill-In: RICE ≤ 100 AND Effort ≤ 3 PM
Time Sink: RICE ≤ 100 AND Effort > 3 PM
```

### Interview Analysis NLP Methods

**Techniques Used:**
- Keyword extraction for pain points
- Sentiment scoring (VADER or TextBlob)
- Topic modeling for themes
- Entity recognition for competitors
- Frequency analysis for patterns
- Quote selection based on representativeness

**Severity Assessment:**
- Critical: Blocks core workflow, mentioned multiple times
- High: Significant friction, workaround exists
- Medium: Noticeable issue, low frequency
- Low: Minor annoyance, edge case

### PRD Template Structure

**Standard PRD Sections:**
1. Overview & Objectives
2. Problem Statement
3. Target Users & Personas
4. Success Metrics
5. Solution Overview
6. User Stories & Scenarios
7. Functional Requirements
8. Non-Functional Requirements
9. Out of Scope
10. Dependencies & Risks
11. Timeline & Milestones

**One-Page PRD Sections:**
1. Problem (Why?)
2. Solution (What?)
3. Metrics (How do we know it works?)
4. Users (Who for?)
5. Scope (What's in/out?)

## Use Cases and Examples

### Prioritizing Q3 Roadmap

**Scenario:** Product team with 20 person-months capacity for Q3

**Input Features:**
```csv
name,reach,impact,confidence,effort
Mobile Offline Mode,15000,massive,medium,xl
Bulk Edit,8000,high,high,m
Export Templates,5000,high,high,s
Advanced Search,12000,medium,medium,l
Dark Mode,20000,low,high,s
Admin Dashboard,3000,high,medium,l
API Rate Limits,1000,high,high,xs
```

**After RICE Analysis:**
```
Top Features by Score:
1. API Rate Limits (Score: 666.67) - Quick Win
2. Export Templates (Score: 333.33) - Quick Win
3. Bulk Edit (Score: 266.67) - Quick Win
4. Dark Mode (Score: 66.67) - Fill-In
5. Admin Dashboard (Score: 40.00) - Time Sink

Q3 Roadmap (20 PM capacity):
✓ API Rate Limits (0.5 PM)
✓ Export Templates (1.5 PM)
✓ Bulk Edit (3 PM)
✓ Advanced Search (6 PM)
✓ Mobile Offline Mode (12 PM)
Total: 23 PM (Slightly over capacity)

Decision: Defer Mobile Offline to Q4, ship other 4 features
Adjusted Total: 11 PM (9 PM buffer for bugs/support)
```

**Portfolio Analysis:**
- Quick Wins: 3 features (ship all)
- Big Bets: 1 feature (Mobile - defer to Q4)
- Fill-Ins: 1 feature (Dark Mode - ship if capacity)
- Time Sinks: 1 feature (Admin Dashboard - reconsider)

### Synthesizing Customer Feedback

**Scenario:** 10 customer interviews about new feature area

**Process:**
1. Conduct 10 interviews with target users
2. Transcribe each interview
3. Run analyzer on each: `python scripts/customer_interview_analyzer.py interview_*.txt`
4. Aggregate results in spreadsheet

**Aggregated Findings:**
```
Top Pain Points (by mention frequency):
1. Data export slow/confusing (8/10 interviews) - CRITICAL
2. No bulk editing (7/10) - HIGH
3. Search doesn't find what I need (6/10) - HIGH
4. Mobile app clunky (5/10) - MEDIUM
5. No dark mode (4/10) - LOW

Top Feature Requests:
1. Export templates (7/10)
2. Bulk edit (7/10)
3. Smart search (6/10)
4. Mobile improvements (5/10)
5. Dark mode (4/10)

Jobs to Be Done:
- Export data for monthly reports (8/10)
- Update multiple items at once (7/10)
- Find specific items quickly (6/10)
- Work on mobile during commute (5/10)

Overall Sentiment: Neutral (0.2)
- Love core product
- Frustrated with gaps
- Willing to recommend despite issues
```

**Product Implications:**
- P0: Fix export experience (critical pain + high request)
- P0: Add bulk edit (high pain + high request)
- P1: Improve search (high pain + medium request)
- P2: Mobile improvements (medium pain + medium request)
- P3: Dark mode (low pain, nice-to-have)

### Writing PRD for Complex Feature

**Scenario:** Adding team collaboration features to individual product

**Template:** Standard PRD (complex feature, 8 weeks)

**Key Sections:**

**Problem Statement:**
"Individual users love our product but can't effectively collaborate with teammates. 60% of users report manually sharing work via email/screenshots. This friction prevents team adoption and limits expansion revenue."

**Target Users:**
- Primary: Team leads (currently individual users)
- Secondary: Team members being invited
- Tertiary: Enterprise admins managing multiple teams

**Success Metrics:**
- 30% of individual users upgrade to team plan
- Average team size of 5 users
- 80% of teams remain active after 30 days
- NPS 50+ for team features

**Solution Overview:**
Phase 1 (4 weeks):
- Team creation and invitations
- Shared workspace
- Basic permissions (view/edit)
- Team billing

Phase 2 (4 weeks):
- Advanced permissions (custom roles)
- Activity feed
- Comments and @mentions
- Team templates

**Out of Scope (V1):**
- Real-time collaboration
- Video/audio communication
- External guest access
- Advanced analytics

**Dependencies:**
- Billing system updates (2 weeks, Engineering)
- New permissions system (3 weeks, Engineering)
- Team UI redesign (4 weeks, Design)

**Risks:**
- Migration complexity for existing users
- Performance with large teams (>50 users)
- Permissions model confusion

**Mitigation:**
- Gradual rollout with beta program
- Performance testing with synthetic data
- User testing on permissions UI

## Best Practices

### Effective Prioritization

**Do:**
- Mix quick wins with strategic bets (aim for 40/40/20: quick wins/big bets/strategic)
- Consider opportunity cost (what are we NOT doing?)
- Account for dependencies and sequencing
- Buffer 20% for unexpected work and tech debt
- Revisit priorities quarterly
- Communicate decisions clearly with rationale

**Don't:**
- Rely solely on scoring (use judgment too)
- Ignore strategic initiatives for higher scores
- Underestimate effort (add buffer)
- Cherry-pick from bottom of backlog
- Change priorities mid-quarter without cause
- Skip stakeholder communication

### Writing Great PRDs

**Do:**
- Start with problem, not solution
- Include clear success metrics upfront
- Explicitly state what's out of scope
- Use visuals (wireframes, flows, diagrams)
- Keep technical details in appendix
- Version control all changes
- Get stakeholder sign-off before implementation

**Don't:**
- Jump to solution without validation
- Write PRD without talking to users
- Make it a spec for engineers to follow blindly
- Over-spec (leave room for design/eng creativity)
- Write and forget (PRD is living document)
- Skip the "out of scope" section

### Customer Discovery

**Do:**
- Ask "why" at least 5 times
- Focus on past behavior, not future intentions
- Avoid leading questions
- Interview in their environment when possible
- Look for emotional reactions (they reveal truth)
- Validate qualitative with quantitative data
- Interview across user segments

**Don't:**
- Ask "would you use this feature?"
- Present solution and ask for feedback only
- Interview only friendly customers
- Take feature requests at face value
- Interview without hypothesis
- Skip synthesis and analysis

### Stakeholder Management

**Do:**
- Identify RACI for decisions early
- Send regular async updates (weekly)
- Demo over documentation when possible
- Address concerns early (don't avoid)
- Celebrate wins publicly
- Learn from failures openly
- Build trust through transparency

**Don't:**
- Spring surprises on stakeholders
- Over-communicate (respect their time)
- Make unilateral decisions on shared concerns
- Hide bad news or delays
- Take all feedback as requirements
- Manage up without managing across

## Integration Points

This skill integrates with:
- **Analytics:** Amplitude, Mixpanel, Google Analytics (for reach/impact data)
- **Roadmapping:** ProductBoard, Aha!, Roadmunk (import RICE scores)
- **Design:** Figma, Sketch, Miro (PRD visuals, synthesis)
- **Development:** Jira, Linear, GitHub (PRD linking, tracking)
- **Research:** Dovetail, UserVoice, Pendo (interview synthesis)
- **Communication:** Slack, Notion, Confluence (PRD distribution)
- **Customer Feedback:** Intercom, Zendesk, Productboard (pain point validation)

## Common Challenges and Solutions

### Challenge: Analysis Paralysis in Prioritization
**Solution:** Set time limits for scoring, use 80/20 rule, make decision and iterate, trust your judgment with data support

### Challenge: Conflicting Stakeholder Priorities
**Solution:** Use transparent framework (RICE), align on strategy first, make trade-offs explicit, escalate to executive sponsor if needed

### Challenge: Feature Requests vs. User Needs
**Solution:** Always ask "what problem are you solving?", validate with multiple users, prototype before committing, test actual behavior

### Challenge: PRD Becoming Outdated
**Solution:** Treat as living document, update with learnings, link to source of truth (Jira/Notion), archive old versions, review before each phase

### Challenge: Interview Bias
**Solution:** Interview diverse segments, ask open-ended questions, separate observation from interpretation, validate with quantitative data, use multiple interviewers

### Challenge: Roadmap Commitment Pressure
**Solution:** Communicate ranges not dates, build in buffer, show confidence levels, update regularly, manage expectations early
