# UX Research (UX Researcher & Designer)

## Overview

The UX Research skill provides a comprehensive toolkit for user-centered research and experience design. This skill enables data-driven persona generation, customer journey mapping, usability testing frameworks, and research synthesis, ensuring design decisions are grounded in real user insights and validated through systematic research methods.

## Who Should Use This Skill

- **Senior UX Researchers** conducting comprehensive user studies
- **UX Designers** integrating research into design process
- **Product Managers** understanding user needs and pain points
- **Design Researchers** synthesizing qualitative and quantitative data
- **Service Designers** mapping end-to-end user experiences
- **Research Operations Teams** managing research programs at scale

## Purpose and Use Cases

Use this skill when you need to:
- Generate research-backed user personas from interview data
- Create data-driven customer journey maps
- Conduct systematic usability testing
- Synthesize research findings into actionable insights
- Validate design decisions with user feedback
- Identify user behavior patterns and pain points
- Extract psychographic profiles from user data
- Generate design recommendations from research
- Build empathy with target users

**Keywords that trigger this skill:** user research, persona generation, journey mapping, usability testing, user interviews, research synthesis, user insights, empathy mapping, user behavior

## What's Included

### Persona Generator

**Data-Driven Persona Creation:**
- Analyzes user interview transcripts and behavioral data
- Identifies distinct persona archetypes
- Extracts demographic and psychographic patterns
- Generates realistic user scenarios
- Provides design implications for each persona
- Calculates confidence scores based on sample size
- Creates actionable persona profiles

**Persona Components:**
- **Demographics:** Age, occupation, location, education
- **Psychographics:** Goals, motivations, frustrations, values
- **Behavioral Patterns:** Usage frequency, feature preferences, workflows
- **Pain Points:** Ranked by severity and frequency
- **Needs and Goals:** What users are trying to accomplish
- **Technology Profile:** Device usage, technical proficiency
- **Quote:** Representative statement capturing persona essence

**Statistical Validation:**
- Sample size tracking
- Confidence intervals for patterns
- Statistical significance of findings
- Inter-rater reliability for qualitative coding
- Triangulation across data sources

### Journey Mapping Framework

**Journey Map Components:**
- **Stages:** Awareness → Consideration → Purchase → Use → Advocacy
- **User Actions:** What users do at each stage
- **Touchpoints:** Where interactions occur
- **Emotions:** How users feel throughout journey
- **Pain Points:** Friction and frustration areas
- **Opportunities:** Where to improve experience
- **Metrics:** KPIs for each stage

**Journey Map Types:**
- Current state (as-is) journey maps
- Future state (to-be) journey maps
- Day-in-the-life maps
- Service blueprints
- Experience maps

### Usability Testing Framework

**Testing Methodologies:**
- Moderated usability testing
- Unmoderated remote testing
- Think-aloud protocols
- A/B testing frameworks
- First-click testing
- Five-second testing
- Card sorting exercises

**Testing Artifacts:**
- Test plan templates
- Participant screeners
- Task scenarios
- Success metrics definitions
- Observation protocols
- Severity rating scales
- Reporting templates

### Research Synthesis Tools

**Analysis Methods:**
- Affinity diagramming
- Thematic analysis
- Pattern identification
- Insight extraction
- Priority ranking
- Opportunity mapping
- Recommendation generation

**Output Formats:**
- Research reports
- Insight presentations
- Design implications
- Opportunity backlogs
- Strategic recommendations
- Executive summaries

## How It Works

### Persona Generation Process

**Step 1: Data Collection**
- Gather user interviews (transcripts or notes)
- Collect behavioral analytics
- Include demographic information
- Compile survey responses

**Step 2: Data Preparation**
Create JSON input file:
```json
{
  "interviews": [
    {
      "participant_id": "P001",
      "demographics": {
        "age": 32,
        "occupation": "Marketing Manager",
        "tech_proficiency": "high"
      },
      "transcript": "Interview transcript...",
      "behaviors": ["uses daily", "prefers mobile"],
      "pain_points": ["slow load times", "complex navigation"]
    }
  ]
}
```

**Step 3: Generate Personas**
```bash
python scripts/persona_generator.py user_data.json
```

**Step 4: Output Analysis**
The script produces:
- 3-5 distinct persona profiles
- Behavioral pattern clusters
- Psychographic insights
- Design implications
- Confidence scores
- Supporting quotes

**Persona Profile Structure:**
```
[Persona Name] - The [Archetype]

DEMOGRAPHICS
- Age: [range]
- Occupation: [role]
- Location: [type]
- Tech Proficiency: [level]

PSYCHOGRAPHICS
Goals:
• [Primary goal]
• [Secondary goal]

Frustrations:
• [Major pain point]
• [Common frustration]

Values:
• [Core value 1]
• [Core value 2]

BEHAVIORAL PATTERNS
• [Usage pattern]
• [Preference pattern]
• [Workflow pattern]

QUOTE
"[Representative quote]"

DESIGN IMPLICATIONS
• [Recommendation 1]
• [Recommendation 2]

Confidence: [High/Medium/Low] (n=[sample size])
```

### Research Analysis Workflow

**Qualitative Data Analysis:**
1. **Transcription:** Convert interviews to text
2. **Coding:** Identify themes and patterns
3. **Categorization:** Group similar findings
4. **Pattern Recognition:** Identify behavioral trends
5. **Insight Extraction:** Derive actionable insights
6. **Validation:** Cross-check with quantitative data

**Quantitative Data Integration:**
1. **Analytics Review:** Usage metrics, conversion rates
2. **Survey Analysis:** Aggregate responses
3. **Behavioral Tracking:** User flow analysis
4. **Statistical Analysis:** Significance testing
5. **Correlation:** Connect qual and quant findings

### Journey Mapping Process

**Step 1: Define Scope**
- Select persona
- Identify journey to map
- Set boundaries (start/end points)
- Define granularity level

**Step 2: Research**
- Conduct user interviews
- Observe actual behavior
- Review analytics data
- Gather touchpoint inventory

**Step 3: Map Creation**
- Plot journey stages
- Document actions and thoughts
- Map emotional journey
- Identify pain points
- Highlight opportunities

**Step 4: Validation**
- Test with real users
- Verify with stakeholders
- Refine based on feedback
- Prioritize opportunities

## Technical Details

### Persona Generation Algorithm

**Pattern Recognition:**
- Natural language processing on transcripts
- Sentiment analysis for emotional states
- Topic modeling for theme extraction
- Clustering algorithms for archetype identification
- Frequency analysis for common behaviors

**Statistical Methods:**
- K-means clustering for persona grouping
- Chi-square tests for demographic patterns
- Correlation analysis for behavior relationships
- Confidence intervals for sample representation
- Effect size calculations for impact assessment

### Sample Size Requirements

**Minimum Recommendations:**
- **Exploratory Research:** 5-8 participants per persona
- **Generative Research:** 10-15 participants per persona
- **Evaluative Research:** 5 participants for usability issues
- **Quantitative Validation:** 30+ participants for statistical power

**Confidence Scoring:**
- High (80%+): 15+ participants, strong pattern consistency
- Medium (60-79%): 8-14 participants, moderate patterns
- Low (<60%): <8 participants, weak or conflicting patterns

### Data Privacy and Ethics

**Best Practices:**
- Informed consent for all participants
- Data anonymization and de-identification
- Secure storage of sensitive information
- Clear data retention policies
- Compliance with privacy regulations (GDPR, CCPA)
- Transparent research practices

## Use Cases and Examples

### Generating Personas for SaaS Product

**Scenario:** B2B project management tool needs user personas

**Process:**
1. Conduct 20 user interviews across customer segments
2. Collect usage analytics from 500+ active users
3. Run surveys with 200+ respondents
4. Prepare JSON with interview data and metrics
5. Generate personas: `python scripts/persona_generator.py saas_data.json`

**Output:**
- **Persona 1:** "Organized Owen" - Team lead focused on planning
- **Persona 2:** "Collaborative Casey" - Team member prioritizing communication
- **Persona 3:** "Analytical Anna" - Manager needing reporting and insights

Each with detailed goals, frustrations, behaviors, and design implications.

### Journey Mapping for E-commerce

**Scenario:** Optimize online shopping experience

**Journey Stages:**
1. **Discovery:** User finds product through search/ads
   - Touchpoints: Search engines, social media, ads
   - Emotions: Curious, hopeful
   - Pain Points: Too many options, unclear differentiation

2. **Consideration:** Comparing products and reviews
   - Touchpoints: Product pages, reviews, comparison tools
   - Emotions: Analytical, uncertain
   - Pain Points: Conflicting reviews, missing information

3. **Purchase:** Checkout process
   - Touchpoints: Cart, checkout form, payment
   - Emotions: Impatient, anxious about security
   - Pain Points: Complex form, unexpected costs

4. **Fulfillment:** Waiting for delivery
   - Touchpoints: Confirmation email, tracking, delivery
   - Emotions: Anticipation, anxiety if delayed
   - Pain Points: Poor tracking updates, delivery issues

5. **Post-Purchase:** Using product and support
   - Touchpoints: Product, support, follow-up emails
   - Emotions: Satisfied or disappointed
   - Pain Points: Difficult returns, poor support

**Opportunities Identified:**
- Simplify product comparison
- Add video reviews
- Streamline checkout
- Improve delivery tracking
- Proactive customer support

### Usability Testing for Mobile App

**Scenario:** Testing new feature before launch

**Test Setup:**
- **Participants:** 8 users matching target personas
- **Tasks:** 5 key user flows
- **Metrics:** Task success rate, time on task, errors, satisfaction
- **Method:** Moderated remote testing with think-aloud

**Findings:**
- Task 1: 75% success rate (target: 90%) - navigation unclear
- Task 2: 100% success rate - intuitive design
- Task 3: 50% success rate - missing affordance
- Average satisfaction: 6.5/10 - needs improvement

**Recommendations:**
- Add onboarding tooltips for Task 1
- Redesign button for Task 3 with clear label
- Conduct follow-up testing after changes

### Research Synthesis for Product Strategy

**Scenario:** Synthesizing 3 months of continuous research

**Data Sources:**
- 30 user interviews
- 15 usability tests
- 500+ survey responses
- Analytics from 10,000+ users
- 200+ support tickets

**Synthesis Process:**
1. Organize findings in affinity diagram
2. Identify 8 major themes
3. Extract 15 key insights
4. Prioritize by impact and frequency
5. Generate 10 strategic recommendations

**Key Insight Example:**
"Users struggle with advanced features not because they're complex, but because they're hidden. 80% of support tickets about 'missing features' were for existing functionality."

**Recommendation:**
"Implement progressive disclosure with contextual feature discovery, reducing support burden by estimated 40%."

## Best Practices

### Conducting Effective Interviews

**Preparation:**
- Create interview guide with open-ended questions
- Recruit representative participants
- Prepare consent forms and recording setup
- Practice active listening techniques

**During Interview:**
- Start with warm-up questions
- Ask "why" to understand motivations
- Avoid leading questions
- Embrace silence - let participants think
- Probe for specific examples
- Take detailed notes even if recording

**Question Examples:**
- Good: "Walk me through the last time you used [feature]"
- Bad: "Do you like [feature]?"
- Good: "What frustrates you most about this process?"
- Bad: "Don't you think this is frustrating?"

### Persona Best Practices

**Do:**
- Base personas on real data, not assumptions
- Create 3-5 primary personas (avoid proliferation)
- Include both goals and pain points
- Make personas memorable with names and photos
- Show confidence level and sample size
- Update personas as you learn more

**Don't:**
- Create personas based solely on demographics
- Make too many personas (reduces focus)
- Create personas you want vs. personas that exist
- Let personas become stereotypes or caricatures
- Treat personas as static - they should evolve
- Skip validation with stakeholders

### Journey Mapping Best Practices

**Effective Maps:**
- Focus on one persona per journey
- Include both rational and emotional journey
- Base on actual behavior, not ideal behavior
- Make pain points visible and specific
- Highlight opportunities, not just problems
- Keep maps living documents

**Avoid:**
- Making maps too complex or detailed
- Mapping internal processes instead of user experience
- Creating beautiful maps that no one uses
- Skipping validation with real users
- Ignoring emotional journey
- Treating maps as final deliverables vs. tools

### Research Synthesis Tips

**Organize Findings:**
- Use consistent tagging and categorization
- Separate observations from interpretations
- Track source and frequency of findings
- Link insights back to raw data
- Maintain research repository

**Communicate Insights:**
- Tell stories with data
- Use quotes to illustrate points
- Visualize patterns and trends
- Prioritize insights by impact
- Make recommendations specific and actionable
- Present to stakeholders early and often

### Building Research Practice

**Democratize Research:**
- Train team members in basic research methods
- Share research findings widely
- Create research highlight reels
- Invite team to observe sessions
- Build a research insights library

**Continuous Learning:**
- Conduct regular research sprints
- Mix qualitative and quantitative methods
- Test early and often
- Build feedback loops into product
- Measure impact of research on product decisions

## Integration Points

This skill integrates with:
- **Research Tools:** Dovetail, UserTesting, Optimal Workshop, Maze
- **Analytics:** Amplitude, Mixpanel, Google Analytics, Hotjar
- **Surveys:** Qualtrics, SurveyMonkey, Typeform
- **Collaboration:** Miro, Mural, FigJam (for synthesis)
- **Design Tools:** Figma, Sketch (for persona and journey artifacts)
- **Product Tools:** Jira, ProductBoard (for insights integration)
- **Communication:** Slack, Notion, Confluence (for sharing insights)

## Common Challenges and Solutions

### Challenge: Recruiting Participants
**Solution:** Build a research panel, offer incentives, partner with customer success, use screening surveys, leverage social media

### Challenge: Stakeholder Buy-in
**Solution:** Share highlights regularly, invite to sessions, show impact with case studies, align research with business goals, communicate in stakeholder language

### Challenge: Analysis Paralysis
**Solution:** Set time limits for synthesis, focus on actionable insights, use frameworks for prioritization, ship iterative learnings, avoid perfection

### Challenge: Research-Design Gap
**Solution:** Involve designers in research, create design implications for every finding, co-create with designers, embed researchers in product teams

### Challenge: Scaling Research
**Solution:** Create research templates, train non-researchers, use unmoderated testing, build self-service tools, focus on strategic research

### Challenge: Proving Research ROI
**Solution:** Track metrics before/after research-informed changes, document prevented mistakes, calculate time saved, measure adoption of insights, build case studies
