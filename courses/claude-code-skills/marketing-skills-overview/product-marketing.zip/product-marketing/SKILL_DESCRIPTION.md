# Product Marketing Strategy (marketing-strategy-pmm)

## Overview

The Product Marketing Strategy skill provides a comprehensive framework for Series A+ startups expanding internationally with hybrid PLG/Sales-Led motion. This skill delivers expert positioning methodology (April Dunford framework), competitive intelligence systems, go-to-market playbooks, and international market entry strategies specifically designed for B2B SaaS companies scaling from $1-5M to $10M+ ARR.

## Who Should Use This Skill

- **Product Marketing Managers (PMM)** - Building positioning, competitive battlecards, launch strategies, and sales enablement
- **Heads of Marketing** - Designing overall marketing strategy, budget allocation, pipeline targets, and team structure
- **Heads of Growth** - Planning experimentation frameworks, activation loops, retention strategies, and growth metrics
- **CMOs/VPs of Marketing** - Executive strategy, board reporting, team leadership, and market expansion
- **Founders/CEOs** - Strategic positioning decisions and market entry planning for Series A+ stage companies
- **Sales Leaders** - Understanding positioning to improve win rates and competitive positioning in deals

## Purpose and Use Cases

Use this skill when you need to:

- **Develop positioning and messaging** - Apply April Dunford methodology to find differentiated market position
- **Plan product launches** - Execute 90-day launch playbooks with pre-launch, launch, and post-launch phases
- **Build competitive intelligence** - Create battlecards, track competitors, conduct win/loss analysis
- **Enter new markets** - Expand internationally (US, Canada, UK, Germany, France) with localization strategies
- **Enable sales teams** - Develop sales decks, demo scripts, objection handling, and competitive talk tracks
- **Define ICP and personas** - Establish ideal customer profile with firmographic, technographic, and psychographic criteria
- **Create messaging hierarchy** - Build value propositions, key benefits, feature mapping, and proof points
- **Establish GTM strategy** - Choose PLG, Sales-Led, or Hybrid motion with channel strategies
- **Track PMM metrics** - Monitor product adoption, win rate, sales velocity, deal size, and competitive performance

**Keywords that trigger this skill:** product marketing, positioning, GTM, go-to-market strategy, competitive analysis, competitive intelligence, battlecards, ICP, ideal customer profile, messaging, value proposition, product launch, market entry, international expansion, sales enablement, win loss analysis, PMM, product marketing manager, market positioning, competitive landscape, April Dunford

## What's Included

### Strategic Foundation

**Company Strategy Framework for Series A Context:**
- Current state analysis (funding stage, team size, revenue, market position)
- Strategic priorities in order (positioning, acquisition, retention, expansion, brand)
- Growth rate targets (3-5x YoY for Series A)
- Key challenges and opportunities

**ICP (Ideal Customer Profile) Definition:**
- B2B SaaS ICP framework with firmographics, technographics, psychographics
- Buyer persona development (Economic Buyer, Technical Buyer, User/Champion)
- ICP validation checklist with HubSpot tracking implementation
- ICP fit scoring system (A/B/C/D grading)

**Market Segmentation Strategy:**
- Segmentation by company size (SMB, Mid-Market, Enterprise)
- Vertical market selection (horizontal vs. vertical approaches)
- Use case segmentation with messaging variations
- Geographic prioritization (US/Canada, UK, DACH, France, Nordics)
- Budget allocation across segments

### Positioning & Messaging

**April Dunford Positioning Framework:**
- Step 1: List true competitive alternatives (competitors, status quo, DIY, do nothing)
- Step 2: Isolate unique attributes (features and capabilities only you have)
- Step 3: Map attributes to customer value (how attributes translate to outcomes)
- Step 4: Define best-fit customers (who cares most about this value)
- Step 5: Nail market category (head-to-head, niche, or new category)
- Step 6: Layer on trends (market timing and momentum)

**Messaging Architecture:**
- Value proposition one-liner template
- Messaging hierarchy (L1: Value Prop, L2: Benefits, L3: Features, L4: Proof Points)
- Persona-specific messaging (Economic Buyer, Technical Buyer, End User)
- Messaging testing framework (qualitative interviews, A/B testing, sales feedback)
- Iteration cycle (quarterly refresh process)

### Competitive Intelligence

**Competitive Analysis Framework:**
- Competitor tier system (Tier 1: Direct, Tier 2: Indirect, Tier 3: Status Quo)
- 10 competitive intelligence sources (product trials, website monitoring, customer interviews, etc.)
- Information gathering methodology

**Competitive Battlecards:**
- Comprehensive battlecard template (overview, positioning, strengths/weaknesses, advantages, talk tracks)
- When to win / when to lose analysis
- Proof points and competitive positioning maps
- Distribution and update protocols (monthly refresh)

**Win/Loss Analysis:**
- Interview process (goals, methodology, questions)
- Win/loss data tracking in HubSpot
- Monthly insights reporting template
- Action item generation for product, sales, and marketing

### Go-To-Market (GTM) Strategy

**GTM Motion Types:**
- PLG (Product-Led Growth) playbook
- Sales-Led Growth playbook
- Hybrid PLG+Sales approach (recommended for Series A)
- Motion selection criteria and ACV considerations

**GTM Launch Playbook (90-Day Plan):**
- Pre-Launch (Days -90 to -30): Foundation, content/enablement, channel setup
- Launch (Days 1-30): Awareness week, activation weeks
- Post-Launch (Days 31-90): Optimization, scaling
- Complete checklists for each phase

**International Market Entry:**
- Market entry priority (US → UK → DACH → France → Canada)
- Phase-by-phase expansion strategy with timelines and budgets
- Localization checklist (website, product, pricing, support, legal, sales, marketing, payments)
- Budget allocation by market with expected ROI
- GDPR and data privacy compliance considerations

### Product Launch Framework

**Launch Tiers:**
- Tier 1: Major Launch (quarterly, high impact, $50k-$100k budget)
- Tier 2: Standard Launch (monthly, medium impact, $10k-$25k budget)
- Tier 3: Minor Launch (weekly, low impact, <$5k budget)

**Major Launch Playbook (8-Week Timeline):**
- Week-by-week checklist from -8 weeks to +4 weeks post-launch
- Launch day checklist and daily monitoring protocols
- Post-launch analysis and reporting

**Launch Metrics Dashboard:**
- Leading indicators (traffic, demos, signups, MQLs, pipeline)
- Lagging indicators (SQLs, deals closed, win rate, adoption rate, NPS)
- HubSpot dashboard configuration

### Sales Enablement & Collaboration

**Sales Enablement Assets:**
- Sales deck template (15-20 slides with guidelines)
- One-pagers (product overview, competitive comparison, case study, pricing)
- Demo script with timing and flow
- Email templates for each stage
- ROI calculator template

**Sales Training Program:**
- Monthly enablement calls (agenda and format)
- Quarterly training workshops (topics and structure)
- Sales onboarding program (4-week certification)

**Marketing ↔ Sales Handoffs:**
- MQL → SQL handoff protocols
- Weekly sync agenda
- Quarterly business review (QBR) format
- Communication channels (Slack, HubSpot, Notion)

### Metrics & Analytics

**PMM KPIs (Track Monthly):**
- Product adoption rate (% of customers using feature within 30/90 days)
- Sales velocity (days from SQL to closed won)
- Win rate (% of opportunities won vs. competitors, target >30%)
- Deal size (ACV growth, target 25% YoY)
- Launch impact (pipeline $ generated, 3:1 ROMI target)
- Competitive win rate (by competitor)

**HubSpot Reporting:**
- Custom report templates (product launch impact, competitive win rate, sales enablement usage)
- Dashboard configuration examples

**Quarterly Business Review (QBR):**
- QBR template for executive presentation
- Metrics dashboard slide
- Key insights slide (what worked, what didn't, action items)
- Next quarter plan slide

### Quick Reference Resources

**PMM Monthly Checklist:**
- Week 1: Strategy & Planning
- Week 2: Content & Enablement
- Week 3: Launches & Campaigns
- Week 4: Reporting & Iteration

**Positioning Development Timeline:**
- 6-week end-to-end positioning development process

**Team Handoff Protocols:**
- PMM → Demand Gen (deliverables, frequency, SLA)
- PMM → Sales (deliverables, frequency, SLA)
- PMM → Product (deliverables, frequency, SLA)
- PMM → Customer Success (deliverables, frequency, SLA)

## How It Works

### Strategic Planning Process

**Step 1: Foundation Setup**
1. Analyze current company stage (Series A context, funding, team size, revenue)
2. Define ICP using firmographic, technographic, and psychographic criteria
3. Develop 3-5 buyer personas (Economic Buyer, Technical Buyer, User/Champion)
4. Validate ICP with existing customer data (win rate, LTV, churn, engagement)
5. Set up HubSpot ICP tracking with A/B/C/D scoring

**Step 2: Market Segmentation**
1. Choose primary segment (company size, vertical, use case, geography)
2. Create segmentation priority matrix
3. Allocate budget by segment based on TAM, win rate, and strategic fit
4. Document segment-specific messaging and positioning

### Positioning Development

**Step 3: April Dunford Positioning Exercise**
1. List all competitive alternatives (direct competitors, status quo, DIY, do nothing)
2. Identify unique attributes that alternatives don't have
3. Map each unique attribute to customer value and business outcomes
4. Define best-fit customers who care most about these outcomes
5. Choose market category (compete in existing, own niche, or create new)
6. Layer on market trends that make this the right time to buy

**Step 4: Messaging Architecture**
1. Craft value proposition one-liner using template
2. Build messaging hierarchy (value prop → benefits → features → proof points)
3. Create persona-specific messaging for each buyer type
4. Test messaging through customer interviews, A/B tests, and sales feedback
5. Iterate quarterly based on win/loss data and market feedback

### Competitive Intelligence

**Step 5: Competitive Analysis**
1. Identify competitors by tier (Tier 1: Direct, Tier 2: Indirect, Tier 3: Status Quo)
2. Gather intelligence from 10 sources (trials, website, customers, sales calls, reviews, etc.)
3. Create battlecard for each Tier 1 competitor using template
4. Distribute battlecards to sales, CS, product, and marketing teams
5. Update monthly or when competitor launches major changes

**Step 6: Win/Loss Analysis**
1. Conduct win/loss interviews within 30 days of deal close
2. Track reasons in HubSpot (product fit, price, features, competitor relationship)
3. Analyze monthly for patterns and trends
4. Create monthly insights report for product, sales, and marketing
5. Generate action items (product roadmap, battlecard updates, messaging changes)

### GTM Strategy & Launches

**Step 7: GTM Motion Selection**
1. Choose PLG, Sales-Led, or Hybrid motion based on ACV and buyer behavior
2. Define channel strategy (paid, organic, partnerships, sales)
3. Set budget allocation across channels
4. Establish success metrics (MQLs, SQLs, pipeline $, CAC, win rate)

**Step 8: Product Launch Execution**
1. Determine launch tier (Tier 1: Major, Tier 2: Standard, Tier 3: Minor)
2. Follow 8-week timeline for major launches (or abbreviated for Tier 2/3)
3. Execute pre-launch, launch week, and post-launch checklists
4. Monitor metrics dashboard daily during launch week
5. Publish post-launch report with results vs. goals and learnings

### International Expansion

**Step 9: Market Entry Planning**
1. Prioritize markets (US → UK → DACH → France → Canada recommended)
2. Create market-specific entry plan with timeline and budget
3. Complete localization checklist (website, product, pricing, support, legal, sales, marketing)
4. Hire local sales resources or partner with local agencies
5. Track market-specific metrics (ARR, CAC, win rate by geography)

### Sales Enablement

**Step 10: Sales Enablement Development**
1. Create core assets (sales deck, one-pagers, battlecards, demo script, email templates, ROI calculator)
2. Conduct monthly enablement calls (product updates, competitive landscape, win/loss insights)
3. Run quarterly training workshops (positioning refresh, objection handling, product deep dives)
4. Establish handoff protocols (MQL → SQL criteria, SLA, communication channels)
5. Track asset usage and sales feedback to optimize enablement

### Ongoing Optimization

**Step 11: Metrics Tracking & QBR**
1. Monitor PMM KPIs monthly (product adoption, win rate, sales velocity, deal size, launch impact)
2. Configure HubSpot dashboards for real-time visibility
3. Conduct monthly win/loss analysis
4. Prepare quarterly business review for executive team
5. Set next quarter priorities based on data and insights

## Technical Details

### Tech Stack Integration

**HubSpot CRM:**
- Campaign tracking and attribution
- ICP fit scoring properties
- Deal tracking with competitive loss analysis
- Win/loss reason tracking
- Sales enablement content library
- Lead scoring and routing workflows

**Google Analytics:**
- Product usage funnels
- Feature adoption tracking
- Activation metrics by segment

**Gong/Chorus:**
- Sales call recording and analysis
- Competitive intelligence from customer conversations
- Objection tracking and frequency analysis

**Productboard:**
- Customer feature requests
- Win/loss feedback aggregation
- Roadmap prioritization input

**Notion/Confluence:**
- Internal wiki for positioning docs
- Competitive battlecard repository
- Sales enablement knowledge base

### HubSpot Implementation

**ICP Tracking Setup:**
```
1. Create "ICP Fit" property (dropdown: A/B/C/D)
2. Score based on:
   - Firmographics: Company size, industry, revenue
   - Engagement: Product usage, content downloads
   - Buying signals: Demo requests, pricing views
3. Report on: Win rate by ICP score, Pipeline by ICP score
4. Action: Focus acquisition on ICP A/B, nurture C, disqualify D
```

**Competitive Tracking:**
```
1. Create "Primary Competitor" property (dropdown)
2. Create "Competitive Deal" checkbox
3. Create "Loss Reason" property (if Closed Lost)
4. Create "Win Reason" property (if Closed Won)
5. Report on: Win rate by competitor, Deal velocity by competitor
```

**Launch Campaign Tracking:**
```
1. Create campaign in HubSpot
2. Tag all assets with campaign ID
3. Use UTM structure:
   - utm_campaign={launch-name}
   - utm_source={channel}
   - utm_medium={type}
4. Track: MQLs, SQLs, Pipeline $, Closed Won $
5. Calculate: ROMI (pipeline : spend)
```

### Data Sources for Intelligence

**Competitive Intelligence:**
- Direct: Product trials, pricing pages, feature comparisons
- Customer: Win/loss interviews, review sites (G2, Capterra)
- Sales: Call recordings (Gong/Chorus), deal notes in HubSpot
- Market: Job postings, financial filings, press releases
- Social: LinkedIn posts, Twitter, company blogs
- Analyst: Gartner, Forrester reports
- Partners: Implementation partner feedback

**Win/Loss Analysis:**
- Interview sample: 10-15 won deals, 10-15 lost deals per month
- Track in HubSpot: Reason categories, competitor mentions, deal size, sales cycle length
- Analysis frequency: Monthly themes report, quarterly deep dive

### International Expansion Considerations

**Localization Requirements by Market:**

**US/Canada:**
- Language: English (minimal localization)
- Currency: USD/CAD
- Legal: CCPA compliance (California)
- Payment: Credit card, ACH
- Sales: Fast sales cycles (30-60 days)
- Messaging: Direct, ROI-focused

**UK:**
- Language: English (British spelling)
- Currency: GBP
- Legal: GDPR compliance
- Payment: Credit card, SEPA
- Sales: Similar to US (45-75 days)
- Messaging: Slightly more formal

**DACH (Germany/Austria/Switzerland):**
- Language: German (full translation required)
- Currency: EUR/CHF
- Legal: Strict GDPR compliance, data residency
- Payment: SEPA, credit card
- Sales: Longer cycles (60-120 days)
- Messaging: Detail-oriented, security/privacy focus

**France:**
- Language: French (full translation required)
- Currency: EUR
- Legal: GDPR + French data regulations
- Payment: SEPA, credit card
- Sales: Longer cycles (60-120 days)
- Messaging: Relationship-focused, local case studies critical

### Positioning Frameworks

**April Dunford Method (6 Steps):**
```
Step 1: Competitive Alternatives
  → List: Direct competitors, status quo, DIY, do nothing
  → Output: 5-8 alternatives customers actually consider

Step 2: Unique Attributes
  → Identify: Features/capabilities only you have
  → Output: 3-5 unique attributes

Step 3: Value Mapping
  → Translate: Attribute → Customer Value → Business Outcome
  → Output: Value map for each unique attribute

Step 4: Best-Fit Customers
  → Define: Who cares most about this value
  → Validate: Against ICP and win rate data
  → Output: Refined ICP definition

Step 5: Market Category
  → Choose: Compete in existing, own niche, create new
  → Consider: Competitive strength, budget, market maturity
  → Output: Category decision with rationale

Step 6: Trends
  → Layer: Market timing, technology shifts, regulatory changes
  → Output: "Why now" positioning angle
```

### Launch Tiers Decision Matrix

| Factor | Tier 1 (Major) | Tier 2 (Standard) | Tier 3 (Minor) |
|--------|---------------|-------------------|----------------|
| Scope | New product, major feature | Significant feature | Small feature, bug fix |
| Budget | $50k-$100k | $10k-$25k | <$5k |
| Timeline | 6-8 weeks prep | 3-4 weeks prep | 1 week prep |
| Audience | All + press | Customers + prospects | Customers only |
| Activities | Press, webinar, email series, paid ads, sales blitz | Blog, email, product update, sales enablement | In-app notification, changelog |

## Best Practices

### Positioning Best Practices

- **Start with customer conversations** - Conduct 10-15 ICP customer interviews before positioning
- **Use exact customer language** - Quote customers in messaging, avoid marketing jargon
- **Test before committing** - A/B test positioning on landing pages before full rollout
- **Iterate quarterly** - Refresh messaging every 90 days based on win/loss data
- **Focus on outcomes, not features** - Lead with business results, support with product capabilities
- **Differentiate on unique value** - Only highlight what competitors can't match
- **Make it simple** - If you can't explain positioning in 30 seconds, simplify

### Competitive Intelligence Best Practices

- **Update battlecards monthly** - Or immediately after competitor launches major changes
- **Train sales quarterly** - Competitive landscape changes fast, keep sales current
- **Focus on winnable battles** - Don't compete where you can't win, redirect to better fit
- **Make errors actionable** - Provide specific next steps in every battlecard talk track
- **Track win/loss religiously** - 10+ interviews per month minimum for reliable data
- **Share insights cross-functionally** - Product needs competitive gaps, marketing needs positioning updates
- **Use real sales calls** - Listen to Gong/Chorus recordings for authentic competitive conversations

### Launch Best Practices

- **Choose the right tier** - Not everything needs a major launch, save budget for true impact
- **Plan 8 weeks ahead** - Major launches need time for coordination and asset creation
- **Set clear success metrics** - Define goals upfront (pipeline $, MQLs, press coverage)
- **Coordinate cross-functionally** - Align product, marketing, sales, CS early
- **Test before launch** - Beta test with select customers, gather feedback
- **Monitor daily during launch week** - Quick pivots save campaigns
- **Publish post-launch report** - Share learnings with exec team and entire company
- **Apply learnings to next launch** - Iterate launch process based on what worked/didn't

### International Expansion Best Practices

- **Start with US market** - Largest TAM, fastest sales cycles, highest willingness to pay
- **UK as EU gateway** - English-speaking, GDPR-compliant, similar buying behavior
- **Localize meaningfully** - Full translation + local case studies + local sales team
- **Budget 15-20% more for EU paid ads** - Same quality costs more in EU markets
- **Hire local or partner** - Local sales reps or agencies critical for credibility
- **GDPR compliance is table stakes** - Double opt-in, consent tracking, data residency
- **Adapt messaging culturally** - US: ROI-focused. UK: Slightly formal. DACH: Security focus. France: Relationship-oriented

### Sales Enablement Best Practices

- **Create assets sales actually use** - Ask sales what they need, track usage in HubSpot
- **Keep battlecards concise** - 1-2 pages max, easy to review before calls
- **Update based on feedback** - Monthly sales feedback loop on what's working
- **Train on positioning, not features** - Sales needs to sell outcomes, not capabilities
- **Role-play competitive scenarios** - Practice objection handling in training sessions
- **Make assets easy to find** - Centralized library in HubSpot or Notion
- **Celebrate wins** - Share competitive wins in Slack, recognize sales reps

### Metrics & Reporting Best Practices

- **Track leading and lagging indicators** - Leading (MQLs, demos) predict lagging (revenue, win rate)
- **Review weekly, report monthly** - Weekly tactical adjustments, monthly strategic review
- **Segment by ICP fit** - Win rate and CAC vary dramatically by customer fit
- **Attribute accurately** - Use multi-touch attribution for hybrid PLG/Sales motion
- **Compare to benchmarks** - Series A B2B SaaS: 30% win rate, 60-90 day sales cycle
- **Share insights, not just data** - "Win rate up 15% because of new positioning" > "Win rate: 35%"
- **Make QBRs strategic** - Focus on decisions and next quarter priorities, not just retrospective data

## Common Pitfalls to Avoid

- **Don't skip customer research** - Positioning without customer input fails
- **Don't position on features alone** - Features are table stakes, position on unique value
- **Don't create battlecards once and forget** - Competitive landscape changes monthly
- **Don't over-launch** - Too many Tier 1 launches dilute impact and exhaust team
- **Don't expand internationally without local resources** - Translation alone is insufficient
- **Don't enable sales without training** - Assets without training = wasted effort
- **Don't track vanity metrics** - MQLs matter less than pipeline $ and win rate
- **Don't ignore win/loss feedback** - Fastest path to improving product-market fit
- **Don't compete where you can't win** - Redirect to better-fit use cases
- **Don't launch without clear success metrics** - "Successful launch" needs definition upfront

## Resources Included

### Reference Guides in `references/` Directory

**positioning-frameworks.md:**
- Detailed April Dunford positioning methodology
- Geoffrey Moore positioning (Crossing the Chasm)
- Alternative positioning frameworks
- Step-by-step worksheets and templates

**launch-checklists.md:**
- Tier 1/2/3 launch checklists (copy-paste ready)
- Timeline templates for 8-week, 4-week, 1-week launches
- Role assignments and RACI matrices
- Channel-specific tactics (email, social, paid, press)

**international-gtm.md:**
- Market-by-market expansion playbooks
- US, UK, DACH, France, Canada detailed guides
- Localization checklists per market
- Budget allocation templates
- Legal and compliance requirements

**messaging-templates.md:**
- Value proposition templates with examples
- Persona-specific messaging frameworks
- Feature-benefit-outcome mapping templates
- Email and ad copy templates by persona

### Scripts in `scripts/` Directory

**competitor_tracker.py:**
- Monitors competitor websites for pricing, messaging, and feature changes
- Sends Slack alerts when changes detected
- Outputs change log for battlecard updates

**win_loss_analyzer.py:**
- Processes win/loss interview transcripts
- Identifies themes and patterns
- Generates monthly insights report
- Outputs action items by team (product, sales, marketing)

### Assets in `assets/` Directory

**sales-deck-template.pptx:**
- Editable 15-20 slide master deck
- Follows best practice structure
- Includes speaker notes and customization guidance

**battlecard-template.docx:**
- Comprehensive competitive battlecard template
- Sections: Overview, Strengths/Weaknesses, Talk Tracks, Proof Points
- Ready to customize for each competitor

**one-pager-template.pptx:**
- Product overview one-pager design
- Competitive comparison one-pager
- Case study one-pager
- Pricing sheet one-pager

**roi-calculator.xlsx:**
- Customer ROI calculator spreadsheet
- Inputs: Current costs, time spent, team size
- Outputs: Savings, payback period, 3-year ROI
- Customizable assumptions and formulas
