# Content Creation & Brand Voice (content-creator)

## Overview

The Content Creation & Brand Voice skill provides a professional-grade framework for creating SEO-optimized marketing content with consistent brand voice across all channels. This skill includes sophisticated brand voice analysis tools, SEO optimization systems, comprehensive content frameworks for every major content type, and platform-specific social media strategies. Designed for marketing teams that need to produce high-quality, on-brand content at scale while maintaining consistency across blog posts, social media, email, landing pages, and all other marketing channels.

## Who Should Use This Skill

- **Content Marketing Managers** - Planning content strategy, managing editorial calendars, ensuring brand consistency
- **Content Writers & Copywriters** - Creating blog posts, landing pages, email copy, ad copy with SEO optimization
- **Social Media Managers** - Developing platform-specific content strategies, maintaining brand voice across channels
- **Brand Managers** - Establishing and enforcing brand voice guidelines, ensuring consistency across all content
- **Marketing Directors** - Overseeing content strategy, optimizing content ROI, scaling content production
- **Freelance Content Creators** - Understanding brand voice requirements and delivering consistent content
- **SEO Specialists** - Optimizing content for search engines while maintaining readability and brand voice
- **Growth Marketers** - Creating high-converting content across the funnel (awareness, consideration, decision)

## Purpose and Use Cases

Use this skill when you need to:

- **Establish brand voice** - Define voice attributes, personality archetypes, and tone guidelines for consistent communication
- **Create SEO-optimized blog posts** - Write long-form content that ranks in search engines and drives organic traffic
- **Develop social media content** - Create platform-specific content for LinkedIn, Twitter, Facebook, Instagram, TikTok
- **Analyze existing content** - Use brand voice analyzer to assess consistency and readability of current content
- **Optimize content for SEO** - Apply SEO best practices (keyword optimization, structure, meta tags, linking)
- **Plan content calendars** - Schedule content across channels with strategic themes and campaigns
- **Maintain brand consistency** - Ensure all content aligns with brand guidelines regardless of author
- **Repurpose content** - Transform one piece of content into multiple formats for different platforms
- **Write high-converting copy** - Create landing pages, CTAs, email sequences that drive conversions
- **Scale content production** - Establish frameworks and templates for efficient, consistent content creation

**Keywords that trigger this skill:** content creation, blog posts, SEO, brand voice, social media, content calendar, marketing content, content strategy, content marketing, brand consistency, content optimization, social media marketing, content planning, blog writing, content frameworks, brand guidelines, social media strategy, copywriting, SEO writing

## What's Included

### Brand Voice Development

**Brand Voice Analyzer Tool:**
- Automated analysis of existing content for voice characteristics
- Readability scoring (Flesch-Kincaid, Gunning Fog, SMOG index)
- Tone detection (formal/casual, technical/accessible, serious/playful)
- Sentence structure analysis (length, complexity, variety)
- Voice consistency measurement across multiple pieces
- Improvement recommendations with specific examples

**Brand Personality Archetypes:**
- 12 Jungian archetypes adapted for brand voice (Sage, Innocent, Explorer, etc.)
- Primary and secondary archetype selection guidance
- Voice attribute mapping (authoritative, friendly, innovative, trustworthy, etc.)
- Tone spectrum definitions (formal ↔ casual, technical ↔ accessible, serious ↔ playful)
- Example content for each archetype

**Brand Guidelines Framework:**
- Voice definition (personality, tone, values)
- Writing style rules (POV, tense, active vs. passive voice)
- Vocabulary guidelines (preferred terms, words to avoid, industry jargon usage)
- Formatting standards (headings, lists, emphasis, punctuation)
- Example passages demonstrating correct voice application

### SEO Optimization

**SEO Optimizer Tool:**
- Keyword density analysis (target 1-3% for primary keyword)
- Heading structure validation (H1 uniqueness, H2-H6 hierarchy)
- Meta tag optimization (title tag, meta description length and keyword inclusion)
- Content length assessment (benchmark: 1,500-2,500 words for comprehensive content)
- Internal and external linking recommendations
- Image optimization checks (alt text, file names, compression)
- Readability vs. SEO balance scoring
- Specific actionable recommendations prioritized by impact

**Keyword Research Framework:**
- Primary keyword selection (500-5,000 monthly searches, medium difficulty)
- Secondary keyword identification (3-5 supporting keywords)
- LSI (Latent Semantic Indexing) keyword list (10-15 related terms)
- Search intent analysis (informational, navigational, commercial, transactional)
- Keyword placement strategy (title, first 100 words, H2s, conclusion)

**On-Page SEO Checklist:**
- URL structure (short, descriptive, includes keyword)
- Title tag (50-60 characters, includes primary keyword)
- Meta description (150-160 characters, includes keyword and CTA)
- H1 tag (one per page, includes primary keyword)
- H2-H6 hierarchy (logical structure, includes secondary keywords)
- Image optimization (alt text, descriptive filenames, compressed size)
- Internal linking (3-5 relevant internal links)
- External linking (2-3 authoritative external sources)
- Schema markup (Article, HowTo, FAQ structured data)

### Content Frameworks

**Blog Post Templates:**
- **How-To Guide** - Step-by-step instructional content (structure, word count, section breakdown)
- **Listicle** - Numbered list format (optimal list length, item structure, conclusion)
- **Ultimate Guide** - Comprehensive resource (2,500-5,000 words, chapter structure, TOC)
- **Comparison Post** - Product/service comparison (comparison table, criteria, recommendation)
- **Case Study** - Customer success story (challenge-solution-results format, metrics)
- **Thought Leadership** - Opinion/trend analysis (hook, argument structure, evidence, conclusion)

**Landing Page Templates:**
- **Product Page** - Feature-benefit-CTA structure
- **Lead Generation** - Headline, form, value proposition, social proof
- **Demo Request** - Pain point, solution preview, demo booking form
- **Pricing Page** - Plan comparison, feature list, FAQ, CTA

**Email Templates:**
- **Welcome Series** - 3-5 email onboarding sequence
- **Nurture Campaign** - Educational content delivery
- **Promotional Email** - Product announcement, offer, CTA
- **Re-engagement** - Win-back inactive subscribers
- **Transactional** - Order confirmation, receipts, updates

**Social Media Templates:**
- **LinkedIn Post** - Professional insights (optimal length: 150-200 words)
- **Twitter Thread** - Multi-tweet narrative (structure, hooks, CTAs)
- **Instagram Caption** - Visual storytelling (emoji usage, hashtag strategy)
- **Facebook Post** - Community engagement (question prompts, polls)
- **TikTok Script** - Short-form video content (hook-value-CTA in 15-60 seconds)

### Social Media Strategy

**Platform-Specific Best Practices:**

**LinkedIn:**
- Optimal post length: 150-200 words (1,300 characters)
- Best posting times: Tuesday-Thursday, 9am-12pm EST
- Content types: Industry insights, company updates, thought leadership, employee stories
- Engagement tactics: Ask questions, use 3-5 relevant hashtags, tag mentioned companies/people
- Image specs: 1200x627px for link previews, 1080x1080px for image posts

**Twitter/X:**
- Optimal post length: 100-280 characters
- Best posting times: Monday-Friday, 8am-10am and 6pm-9pm EST
- Content types: Quick tips, news commentary, thread deep-dives, polls, behind-the-scenes
- Engagement tactics: Threads for depth, polls for engagement, reply to industry conversations
- Image specs: 1200x675px for in-feed images

**Instagram:**
- Optimal caption length: 125-150 characters for feed, 150-200 for Reels
- Best posting times: Monday-Friday, 11am-2pm EST
- Content types: Visual storytelling, behind-the-scenes, user-generated content, Reels
- Engagement tactics: Use 10-30 hashtags, Stories for engagement, Reels for reach
- Image specs: 1080x1080px (square), 1080x1350px (portrait), 1080x1920px (Stories/Reels)

**Facebook:**
- Optimal post length: 40-80 characters for engagement
- Best posting times: Wednesday-Friday, 9am-11am EST
- Content types: Community building, customer stories, events, live videos
- Engagement tactics: Ask questions, create polls, share user content, respond to comments
- Image specs: 1200x630px for link posts

**TikTok:**
- Optimal video length: 15-60 seconds (21-34 seconds highest engagement)
- Best posting times: Tuesday-Thursday, 7am-9am and 7pm-11pm EST
- Content types: Educational quick tips, behind-the-scenes, trends, challenges
- Engagement tactics: Hook in first 3 seconds, on-screen text, trending audio, hashtag challenges
- Video specs: 1080x1920px (9:16 vertical)

**Hashtag Strategy:**
- Platform mix: LinkedIn (3-5), Instagram (10-30), Twitter (1-3), TikTok (3-5)
- Hashtag types: Brand (1), campaign (1), trending (1-2), niche (2-5), broad (2-5)
- Research: Platform search, competitor analysis, trending topics
- Tracking: Monitor hashtag performance, iterate monthly

### Content Calendar & Planning

**Content Pillar Framework:**
- **Educational (40%)** - How-tos, guides, tutorials, tips
- **Inspirational (25%)** - Success stories, case studies, behind-the-scenes
- **Conversational (25%)** - Questions, polls, user-generated content, community engagement
- **Promotional (10%)** - Product announcements, offers, CTAs

**Monthly Planning Process:**
1. Set monthly goals and KPIs (traffic, leads, engagement)
2. Identify key campaigns and themes
3. Allocate content across pillars (40/25/25/10 ratio)
4. Distribute across platforms (LinkedIn, Twitter, Instagram, blog)
5. Align with optimal posting times
6. Batch create content weekly
7. Review and adjust based on performance

**Editorial Calendar Template:**
- Date, platform, content type, topic/headline
- Primary keyword (for SEO content)
- Content pillar (educational, inspirational, conversational, promotional)
- Status (ideation, writing, review, scheduled, published)
- Author/owner
- Performance metrics (views, engagement, conversions)

### Content Repurposing

**Repurposing Matrix:**
```
Blog Post (2,000 words) →
  - 5-7 LinkedIn posts (key points)
  - 10-15 Twitter posts (tips/quotes)
  - 3-5 Instagram graphics (stats/quotes)
  - 1 Email newsletter (summary + CTA)
  - 1 YouTube video script (5-10 min)
  - 5-10 TikTok/Reel scripts (15-60 sec each)
  - 1 Slide deck (10-15 slides for SlideShare)
  - 1 Infographic (visual summary)
```

**Repurposing Strategy:**
1. Create pillar content (comprehensive blog post, video, guide)
2. Extract key points, stats, quotes, frameworks
3. Adapt for each platform (length, format, tone)
4. Maintain brand voice across all versions
5. Link back to pillar content for traffic
6. Track performance by format and platform

## How It Works

### Brand Voice Development Process

**Step 1: Analyze Existing Content (if available)**
1. Collect 5-10 existing content pieces (blog posts, emails, social posts)
2. Run `brand_voice_analyzer.py` on each piece
3. Review analysis results: tone, formality, readability, sentence structure
4. Identify inconsistencies and patterns
5. Document current voice characteristics

**Step 2: Define Target Brand Voice**
1. Select primary brand archetype (e.g., Sage for thought leadership, Hero for achievement)
2. Choose secondary archetype (for depth and nuance)
3. Define 3-5 voice attributes (e.g., authoritative, approachable, innovative)
4. Set tone spectrum positions (formal/casual, technical/accessible, serious/playful)
5. Write example passages demonstrating target voice

**Step 3: Create Brand Guidelines Document**
1. Document voice definition (personality, values, attributes)
2. Define writing style rules (POV, tense, active voice preference)
3. Create vocabulary guidelines (preferred terms, words to avoid)
4. Set formatting standards (headings, lists, emphasis)
5. Include 5-10 example passages (good vs. bad)
6. Share with all content creators

**Step 4: Train and Validate**
1. Train content team on brand guidelines
2. Create sample pieces for practice
3. Use `brand_voice_analyzer.py` to validate new content
4. Provide feedback and iterate
5. Refine guidelines based on real usage

### SEO-Optimized Content Creation Process

**Step 5: Keyword Research**
1. Identify primary keyword (search volume 500-5,000/month, medium difficulty)
2. Find 3-5 secondary keywords (related searches)
3. List 10-15 LSI keywords (topically related terms)
4. Analyze search intent (what does searcher want to accomplish?)
5. Review SERP competitors (what ranks now? why?)

**Step 6: Content Structure & Outline**
1. Choose appropriate blog template (how-to, listicle, guide, comparison, case study)
2. Create outline with H2-H6 hierarchy
3. Include primary keyword in title and first H2
4. Include secondary keywords in 2-3 H2s
5. Plan 1,500-2,500 word target (longer for competitive keywords)
6. Identify internal linking opportunities (3-5 links)
7. Find external sources to link (2-3 authoritative sites)

**Step 7: Write First Draft**
1. Write without editing (maintain flow)
2. Apply brand voice naturally
3. Include keyword in first 100 words
4. Use keyword naturally throughout (1-3% density)
5. Write for humans first, search engines second
6. Add examples, data, quotes for depth
7. Include clear CTAs (subscribe, demo, download)

**Step 8: SEO Optimization**
1. Run `seo_optimizer.py [file] [primary_keyword] [secondary_keywords]`
2. Review SEO score and recommendations
3. Optimize title tag (50-60 chars, includes keyword)
4. Write meta description (150-160 chars, includes keyword and CTA)
5. Adjust keyword density if needed (target 1-3%)
6. Ensure proper heading hierarchy (one H1, logical H2-H6)
7. Add/optimize internal and external links
8. Write image alt text (includes keywords where natural)

**Step 9: Brand Voice Validation**
1. Run `brand_voice_analyzer.py [file]`
2. Check voice consistency with brand guidelines
3. Verify readability score matches target audience
4. Adjust tone if needed (more formal/casual, technical/accessible)
5. Ensure vocabulary aligns with brand preferences
6. Validate formatting follows brand standards

**Step 10: Final Review & Publishing**
1. Proofread for grammar, spelling, punctuation
2. Fact-check all claims and statistics
3. Test all links (internal and external)
4. Optimize images (compress, add alt text, descriptive filenames)
5. Add schema markup (Article, HowTo, FAQ)
6. Schedule publication at optimal time
7. Promote across social channels

### Social Media Content Creation Process

**Step 11: Platform Selection**
1. Identify primary platforms based on audience (LinkedIn for B2B, Instagram for visual brands)
2. Review platform-specific best practices (length, times, formats)
3. Allocate content across platforms (don't duplicate—adapt)

**Step 12: Content Adaptation**
1. Start with core message or pillar content
2. Use repurposing matrix to plan derivatives
3. Adapt length for each platform (LinkedIn 150-200 words, Twitter 100-280 chars)
4. Adjust tone slightly (LinkedIn more professional, Twitter more casual)
5. Create platform-specific CTAs (LinkedIn: "What's your experience?", Twitter: short hook)

**Step 13: Platform Optimization**
1. Verify optimal length for platform
2. Schedule for optimal posting time
3. Use correct image dimensions
4. Apply hashtag strategy (platform-appropriate count and mix)
5. Add engagement elements (questions, polls, tags)
6. Include clear CTA (like, comment, share, click)

**Step 14: Batch Creation & Scheduling**
1. Create all weekly content in one 2-3 hour session
2. Maintain consistent voice across all pieces
3. Prepare visual assets together (Canva, Figma)
4. Schedule using content calendar template
5. Set up monitoring for engagement (respond within 1-2 hours)

### Content Calendar Planning

**Step 15: Monthly Planning**
1. Copy content calendar template for new month
2. Set monthly goals (traffic, leads, engagement, conversions)
3. Identify key campaigns/themes (product launch, industry event, seasonal)
4. Allocate content across pillars (40% educational, 25% inspirational, 25% conversational, 10% promotional)
5. Distribute across platforms and dates
6. Assign owners and deadlines

**Step 16: Weekly Execution**
1. Review week's content plan Monday morning
2. Batch create content Monday-Tuesday (blog post + social derivatives)
3. Review and optimize Wednesday (SEO, brand voice validation)
4. Schedule Thursday (publish blog, schedule social throughout week)
5. Monitor and engage Friday + ongoing (respond to comments, track metrics)

**Step 17: Monthly Review**
1. Analyze performance by content type, platform, topic
2. Identify top performers (most traffic, engagement, conversions)
3. Identify underperformers (low traffic, no engagement)
4. Adjust next month's plan (double down on winners, cut losers)
5. Update content calendar template based on learnings

## Technical Details

### Brand Voice Analyzer Tool

**Input:** Text file or markdown file with content to analyze

**Output:**
- Voice profile: Formality (0-100), tone attributes, perspective (1st/2nd/3rd person)
- Readability scores: Flesch Reading Ease, Flesch-Kincaid Grade Level, Gunning Fog Index, SMOG Index
- Sentence structure: Average sentence length, sentence length distribution, complexity metrics
- Vocabulary: Word count, unique words, lexical diversity
- Recommendations: 5-10 specific improvements with examples

**Usage:**
```bash
python scripts/brand_voice_analyzer.py content.txt
python scripts/brand_voice_analyzer.py content.txt json  # for JSON output
```

**Analysis Methodology:**
- Lexical analysis for vocabulary complexity
- Syntactic analysis for sentence structure
- Tone detection via keyword presence and patterns
- Readability formulas (Flesch-Kincaid, Gunning Fog, SMOG)
- Comparative analysis across multiple pieces for consistency

### SEO Optimizer Tool

**Input:** Content file, primary keyword, optional secondary keywords

**Output:**
- SEO score (0-100) with breakdown by category
- Keyword density analysis (primary and secondary keywords)
- Heading structure assessment (H1-H6 hierarchy validation)
- Meta tag suggestions (title tag and meta description optimized for keyword)
- Content length assessment (vs. 1,500-2,500 word benchmark)
- Link analysis (internal and external link count and suggestions)
- Image optimization status (alt text, filenames)
- Prioritized recommendations (high/medium/low impact)

**Usage:**
```bash
python scripts/seo_optimizer.py article.md "primary keyword"
python scripts/seo_optimizer.py article.md "primary keyword" "secondary,keyword,list"
```

**SEO Scoring Breakdown:**
- Keyword optimization (25 points): Density, placement, natural usage
- Content structure (25 points): Headings, length, readability
- Meta tags (20 points): Title tag, meta description quality
- Linking (15 points): Internal links, external links, anchor text
- Images (15 points): Alt text, file names, optimization

**Benchmark Targets:**
- Overall SEO score: 75+ (good), 85+ (excellent)
- Primary keyword density: 1-3%
- Content length: 1,500-2,500 words (topic-dependent)
- Internal links: 3-5 per post
- External links: 2-3 authoritative sources
- Readability: Flesch Reading Ease 60-70 (standard), 70-80 (easy)

### Content Framework Specifications

**Blog Post Template Structure:**

**How-To Guide:**
- Introduction (100-150 words): Problem statement, what reader will learn
- Step-by-step instructions (1,200-1,800 words): Each step as H2, sub-steps as H3, screenshots/examples
- Conclusion (100-150 words): Summary, next steps, CTA
- Target length: 1,500-2,500 words
- SEO focus: Include keyword in title, first 100 words, 2-3 H2s

**Listicle:**
- Introduction (100-150 words): Why this list matters, what's included
- List items (1,200-1,800 words): Each item as H2, 150-250 words per item
- Conclusion (100-150 words): Recap, CTA
- Optimal list length: 5-10 items (7 is ideal)
- SEO focus: Number in title ("7 Ways to..."), keyword in intro and list items

**Ultimate Guide:**
- Introduction (200-300 words): Comprehensive overview, table of contents
- Chapters (2,000-4,500 words): Each chapter as H2, sections as H3-H4
- Conclusion (200-300 words): Summary, additional resources, CTA
- Target length: 2,500-5,000 words
- SEO focus: Target high-volume competitive keyword, comprehensive topic coverage

### Platform-Specific Requirements

**LinkedIn:**
- Max length: 3,000 characters (optimal: 150-200 words / 1,300 characters)
- Image size: 1200x627px (link preview), 1080x1080px (image post)
- Video: Up to 10 minutes, 1080x1080px (square) or 1920x1080px (landscape)
- Hashtags: 3-5 relevant hashtags
- Links: LinkedIn suppresses organic reach when links included; put link in first comment

**Twitter/X:**
- Max length: 280 characters (optimal: 100-280 characters)
- Image size: 1200x675px (16:9 ratio)
- Video: Up to 2:20 minutes (verified), 140 seconds (unverified)
- Threads: Break long content into 5-25 tweet threads
- Hashtags: 1-3 hashtags maximum (more reduces engagement)

**Instagram:**
- Caption max: 2,200 characters (optimal: 125-150 for feed, 150-200 for Reels)
- Image size: 1080x1080px (square), 1080x1350px (portrait), 1080x1920px (Stories)
- Video: 3-60 seconds (Feed), 15-90 seconds (Reels)
- Hashtags: 10-30 hashtags (mix of niche and broad)
- First comment: Can include additional hashtags and links

**Facebook:**
- Max length: 63,206 characters (optimal: 40-80 characters for engagement)
- Image size: 1200x630px (link posts), 1080x1080px (image posts)
- Video: Up to 240 minutes, 1080x1080px (square) recommended
- Hashtags: 1-3 hashtags (minimal usage on Facebook)
- Links: No suppression, link previews display well

**TikTok:**
- Video length: 15 seconds to 10 minutes (optimal: 21-34 seconds)
- Video size: 1080x1920px (9:16 vertical, required)
- Caption max: 300 characters (optimal: 100-150 characters)
- Hashtags: 3-5 hashtags (mix of trending and niche)
- On-screen text: Critical for 85% muted viewing

## Best Practices

### Brand Voice Best Practices

- **Document everything** - Brand voice should be in writing, not just "we'll know it when we see it"
- **Use examples liberally** - Show, don't just tell (good vs. bad examples)
- **Start with existing content** - Analyze what you already have before defining new voice
- **Test with team** - Have 3-5 people write sample content, identify inconsistencies
- **Validate regularly** - Use brand voice analyzer monthly on new content
- **Allow flexibility** - Voice can adapt slightly by channel (LinkedIn more formal than Twitter)
- **Train new creators** - Onboard all content creators with brand guidelines
- **Iterate based on feedback** - Refine voice as brand evolves

### SEO Best Practices

- **Research before writing** - Keyword research comes first, writing second
- **Write for humans first** - Content should read naturally, keywords should fit organically
- **Target one primary keyword per post** - Don't try to rank for everything in one piece
- **Longer content ranks better** - 1,500-2,500 words for competitive keywords
- **Update old content** - Refresh top-performing content yearly to maintain rankings
- **Link internally** - Help search engines understand site structure and content relationships
- **Link externally** - Authoritative external links build credibility
- **Optimize images** - Alt text, file names, compression all matter for SEO and accessibility
- **Monitor performance** - Track rankings, traffic, conversions monthly; iterate

### Social Media Best Practices

- **Quality over quantity** - 3 great posts per week > 10 mediocre daily posts
- **Platform-specific content** - Don't just cross-post; adapt for each platform
- **Engage, don't just broadcast** - Respond to comments within 1-2 hours
- **Use platform-native features** - LinkedIn carousels, Twitter threads, Instagram Reels
- **Test posting times** - Track when your audience is most active, adjust schedule
- **Mix content types** - Text, images, videos, polls, questions for variety
- **Track what works** - Analyze top performers monthly, double down on winning formats
- **Batch create** - Create week's content in one session for consistency and efficiency

### Content Calendar Best Practices

- **Plan monthly, execute weekly** - Monthly themes, weekly detailed planning
- **Balance content pillars** - 40% educational, 25% inspirational, 25% conversational, 10% promotional
- **Align with business goals** - Content should support pipeline, revenue, brand goals
- **Build in flexibility** - Leave 20% of calendar open for timely/reactive content
- **Assign clear owners** - Every piece has an owner and deadline
- **Review and iterate** - Monthly performance review, adjust next month's plan
- **Maintain buffer** - Always have 2-3 pieces ready to publish (for emergencies)

## Common Pitfalls to Avoid

- **Don't write before researching keywords** - SEO starts with keyword research, not after writing
- **Don't ignore platform-specific requirements** - Character limits, image sizes, hashtag counts vary
- **Don't sacrifice brand voice for SEO** - Keyword-stuffed content ranks poorly and converts worse
- **Don't publish without proofreading** - Typos and errors damage credibility
- **Don't create content without a goal** - Every piece should support a business objective
- **Don't neglect analytics** - Track performance or you can't improve
- **Don't cross-post without adapting** - Each platform needs platform-optimized content
- **Don't ignore engagement** - Respond to comments, build community
- **Don't create without a calendar** - Ad-hoc content production leads to inconsistency
- **Don't skip the brand voice exercise** - Inconsistent voice confuses audience and dilutes brand

## Resources Included

### Reference Guides in `references/` Directory

**brand_guidelines.md:**
- 12 brand personality archetypes with descriptions and examples
- Voice attribute definitions and spectrum (formal/casual, technical/accessible, serious/playful)
- Writing style rules (POV, tense, active voice, contractions)
- Vocabulary guidelines (preferred terms, words to avoid, jargon usage)
- Example passages for each archetype
- Brand voice definition worksheet

**content_frameworks.md:**
- Detailed templates for 6 blog post types (how-to, listicle, ultimate guide, comparison, case study, thought leadership)
- Landing page structures (product, lead gen, demo request, pricing)
- Email templates (welcome, nurture, promotional, re-engagement, transactional)
- Social media post templates (LinkedIn, Twitter, Instagram, Facebook, TikTok)
- Content repurposing matrix (blog → social → email → video)
- CTA library (50+ high-converting CTAs by use case)

**social_media_optimization.md:**
- Platform-by-platform best practices (LinkedIn, Twitter, Instagram, Facebook, TikTok)
- Optimal posting times by platform and industry
- Image/video specifications for all platforms
- Hashtag research and strategy guidance
- Engagement tactics (questions, polls, user-generated content)
- Algorithm ranking factors for each platform
- Analytics tracking setup (native and third-party tools)
- Platform-specific growth tactics

### Scripts in `scripts/` Directory

**brand_voice_analyzer.py:**
- Input: Text or markdown file
- Analysis: Tone, formality, readability, sentence structure, vocabulary
- Output: Voice profile, readability scores, recommendations (text or JSON format)
- Usage: `python scripts/brand_voice_analyzer.py content.txt [json|text]`

**seo_optimizer.py:**
- Input: Content file, primary keyword, optional secondary keywords
- Analysis: Keyword density, heading structure, meta tags, content length, linking, images
- Output: SEO score (0-100), category breakdown, prioritized recommendations
- Usage: `python scripts/seo_optimizer.py article.md "primary keyword" "secondary,keywords"`

### Assets in `assets/` Directory

**content_calendar_template.md:**
- Monthly planning template (goals, themes, campaigns)
- Weekly content grid (date, platform, type, topic, owner, status)
- Content pillar tracking (educational, inspirational, conversational, promotional percentages)
- Performance tracking (views, engagement, conversions)
- Editable markdown format for easy duplication

**content_briefs/**
- Pre-written content briefs for 20+ common blog post topics
- Includes: Target keyword, outline, word count, internal links, CTAs
- Ready to assign to writers for consistent output
