# Demand Generation & Paid Media (marketing-demand-acquisition)

## Overview

The Demand Generation & Paid Media skill provides a comprehensive acquisition playbook for Series A+ B2B SaaS startups scaling internationally with hybrid PLG/Sales-Led motion. This skill delivers expert strategies for multi-channel demand generation, paid media optimization (LinkedIn, Google, Meta, YouTube), SEO strategy, partnership programs, and HubSpot integration. Designed for performance-driven marketing teams focused on generating pipeline, optimizing CAC, and scaling acquisition across EU, US, and Canada markets.

## Who Should Use This Skill

- **Demand Generation Managers** - Planning multi-channel campaigns, generating pipeline, optimizing funnel conversion
- **Paid Media/Performance Marketers** - Managing paid search, paid social, display advertising with ROI accountability
- **SEO Managers** - Building organic acquisition strategy, technical SEO, content optimization, link building
- **Affiliate/Partnerships Managers** - Establishing co-marketing partnerships, affiliate programs, channel development
- **Growth Marketers** - Running experiments, optimizing conversion rates, scaling winning channels
- **Marketing Operations** - Setting up attribution, campaign tracking, HubSpot workflows, reporting dashboards
- **Marketing Directors/VPs** - Overseeing demand generation strategy, budget allocation, team performance
- **Founders/CEOs** - Understanding acquisition economics, CAC targets, channel mix for Series A stage

## Purpose and Use Cases

Use this skill when you need to:

- **Plan demand generation campaigns** - Full-funnel strategies (TOFU awareness, MOFU consideration, BOFU decision)
- **Optimize paid media** - LinkedIn ads, Google Search/Display, Meta ads, YouTube with ROI tracking
- **Build SEO strategy** - Technical SEO, keyword research, on-page optimization, link building for organic acquisition
- **Establish partnerships** - Strategic partnerships, affiliate programs, co-marketing campaigns, marketplace listings
- **Set up HubSpot tracking** - Campaign attribution, lead scoring, UTM parameters, multi-touch attribution
- **Calculate CAC** - Blended and channel-specific customer acquisition cost with improvement strategies
- **Expand internationally** - EU, US, Canada market entry with localized campaigns and budget allocation
- **Run experiments** - A/B testing framework, ICE prioritization, statistical significance validation
- **Optimize funnel conversion** - Landing page optimization, MQL→SQL conversion, lead nurture sequences
- **Scale acquisition** - Budget allocation, channel mix optimization, team handoff protocols

**Keywords that trigger this skill:** demand generation, paid media, paid ads, LinkedIn ads, Google ads, Meta ads, CAC, customer acquisition cost, lead generation, MQL, SQL, pipeline generation, acquisition strategy, performance marketing, paid social, paid search, partnerships, affiliate marketing, SEO strategy, HubSpot campaigns, marketing automation, B2B marketing, SaaS marketing, funnel optimization, attribution

## What's Included

### Demand Generation Framework

**Full-Funnel Strategy (TOFU-MOFU-BOFU):**
- **TOFU (Top of Funnel / Awareness):** Tactics, channels, metrics for brand awareness and early-stage engagement
- **MOFU (Middle of Funnel / Consideration):** Lead generation, nurture sequences, content strategy for MQLs
- **BOFU (Bottom of Funnel / Decision):** Demo requests, free trials, sales-ready SQLs, pipeline generation
- Funnel stage alignment with channels (paid social for TOFU, paid search for BOFU, etc.)

**Campaign Planning Template:**
- Campaign brief structure (name, objective, budget, duration, channels, audience, offer, success metrics)
- HubSpot campaign setup (campaign ID, lead scoring, attribution model)
- Success metrics definition (primary and secondary KPIs)
- Handoff protocol (SQL criteria, routing, SLA)

**HubSpot Campaign Tracking Setup:**
- Step-by-step campaign creation in HubSpot
- UTM parameter structure (source, medium, campaign, content, term)
- Lead scoring configuration (engagement points, channel quality scoring)
- Attribution reports (first-touch, multi-touch, W-shaped model)

**International Expansion Considerations:**
- EU market entry strategy (GDPR compliance, localization, partnerships, paid channel mix)
- US/Canada market entry strategy (messaging, paid channels, sales alignment)
- Budget allocation by market (recommended split for Series A: US 50%, UK 20%, DACH 15%, France 10%, Canada 5%)

### Paid Media Optimization

**Channel Strategy Matrix:**
- Channel comparison table (LinkedIn, Google Search, Google Display, Meta, YouTube, Reddit/Twitter)
- Best use cases, CAC benchmarks, conversion rates, Series A priority ranking
- Budget allocation recommendations by channel

**LinkedIn Ads Playbook:**
- Campaign structure (campaign groups, campaigns, ad sets, creatives)
- Targeting best practices (company size, job titles, industries, matched audiences)
- Budget recommendations (start $50/day per campaign, scale 20% weekly if CAC < target)
- Creative frameworks (thought leadership, social proof, problem-solution, demo-first)
- Lead Gen Forms vs. Landing Pages (when to use each, HubSpot sync)

**Google Ads Playbook:**
- Campaign types priority (Brand, Competitor, Solution, Product Category, Display Retargeting)
- Search campaign structure (campaigns, ad groups, keywords, responsive search ads)
- Keyword strategy (brand terms, competitor terms, solution terms, problem terms, negative keywords)
- Bid strategy progression (Manual CPC → Target CPA → Maximize Conversions)
- Responsive search ad copy framework (15 headlines, 4 descriptions with strategic pinning)

**Meta Ads Playbook:**
- When to use Meta (product ACV <$10k, visual products, SMB/prosumer audience, awareness campaigns)
- Campaign setup (conversions objective, lookalike audiences, interest targeting, retargeting)
- Creative best practices (video format, 1:1 or 9:16 ratio, hook in first 3 seconds, captions)
- Audience strategy (core audiences, lookalike 1%, retargeting 30-day visitors)

**Budget Allocation & Scaling:**
- Initial budget template (Series A: $30k-50k/month across channels)
- Expected results by channel (MQLs, SQLs, CAC)
- Scaling rules (if CAC < target → increase 20% weekly, if CAC > target → pause/optimize)
- HubSpot ROI dashboard setup (metrics, dimensions, frequency)

### SEO Strategy

**Technical SEO Foundation:**
- Pre-launch checklist (sitemap, robots.txt, HTTPS, page speed, Core Web Vitals, structured data, canonical tags, hreflang)
- Technical audit process (quarterly crawl with Screaming Frog, issue prioritization)
- Critical, high, and medium priority issues

**Keyword Strategy Framework:**
- Keyword research process (seed keywords, tools, analysis, prioritization)
- Keyword tiers (Tier 1: High-Intent BOFU, Tier 2: Solution-Aware MOFU, Tier 3: Problem-Aware TOFU)
- Volume, difficulty, intent, and SERP analysis
- International keyword research (language filters, translation vs. localization, cultural nuances)

**On-Page SEO Template:**
- Page optimization checklist (URL, title tag, meta description, H1, H2-H6, images, internal/external links, schema)
- Content requirements (2,000-3,000 words, 1-2% keyword density, 3-5 internal links, 2-3 external links)
- CTA placement strategy (above fold, mid-content, end)
- Content refresh schedule (quarterly for Tier 1 pages, semi-annually for Tier 2, annually for Tier 3)

**Link Building Strategy:**
- Link acquisition tactics prioritized (Digital PR, Guest Posting, Partnerships, Community Engagement, Broken Link Building)
- Link velocity guidelines (5-10 links/month for new sites, 20-30 links/month after 6 months)
- Anchor text distribution (70% branded, 20% topical, 10% exact match)
- Quality targets (Domain Authority 40+ for guest posts)

**Content Strategy for SEO:**
- Content types by funnel stage (TOFU: guides/listicles, MOFU: comparisons/how-tos, BOFU: product pages/case studies)
- Content calendar minimum (4 TOFU posts/month, 2 MOFU posts/month, 1 BOFU post/month, 2 refreshes/month)

**Local SEO:**
- Google Business Profile setup (per regional office)
- Local citations (Yelp, Yellow Pages, industry directories)
- NAP consistency (Name, Address, Phone identical everywhere)

### Partnerships & Affiliate Programs

**Partnership Types & Strategy:**
- **Tier 1: Strategic Partnerships** (complementary SaaS, co-marketing, product integrations, revenue share)
- **Tier 2: Affiliate Partners** (bloggers, review sites, influencers with 10-30% commission)
- **Tier 3: Referral Partners** (existing customers with $500-$1k per SQL bonus)
- **Tier 4: Marketplace Listings** (Shopify, Salesforce AppExchange, HubSpot Marketplace)

**Partnership Playbook:**
- Partner identification criteria (similar ICP, product fit, scale, values alignment)
- Outreach template (email subject, body, value proposition)
- Partnership agreement structure (scope, revenue model, success metrics, term, exit clause)
- Activation & enablement (co-branded assets, sales training, tracking setup)
- Ongoing management (QBRs, monthly check-ins, co-marketing calendar, reporting dashboard)

**Affiliate Program Setup:**
- Platform selection (PartnerStack for B2B SaaS, Impact for enterprise, Rewardful for lightweight, FirstPromoter for budget)
- Commission structure by tier (30% recurring for influencers, 20% for bloggers, $500 for customers)
- Recruitment strategy (outbound to bloggers/YouTubers, inbound "Become an Affiliate" page, events, communities)
- Affiliate enablement kit (brand assets, pre-written content, tracking links, sales collateral)

**Co-Marketing Campaigns:**
- Joint webinar playbook (6-week timeline: planning, promotion, execution, follow-up)
- Other co-marketing tactics (co-branded content, case studies, bundle offers, cross-promotion, social media takeovers)

**HubSpot Partner Tracking:**
- Partner property setup (dropdown field for partner attribution)
- UTM tracking structure for partner links
- Lead assignment workflow (route partner leads to Partner Manager)
- Reporting dashboard (partner-sourced leads, pipeline, revenue)

### Attribution & Reporting

**Attribution Models:**
- **First-Touch:** Credit to first interaction (use for awareness campaigns)
- **Last-Touch:** Credit to last interaction before conversion (use for direct response)
- **Multi-Touch (W-Shaped):** 40-20-40 split (first, middle, last) - recommended for hybrid PLG/Sales motion
- HubSpot attribution setup and model selection

**Reporting Dashboard:**
- Weekly performance dashboard (traffic, leads, pipeline, CAC, channel mix with dimensions)
- Monthly executive dashboard (marketing-sourced pipeline, revenue, blended CAC, MQL→SQL rate, pipeline velocity, ROMI target 3:1+)
- Insights section (top performers, underperformers, experiments, budget reallocation)

**Google Analytics Setup:**
- Events to track (engagement: page_view, scroll, video_play, file_download; conversions: sign_up, demo_request, contact_form, pricing_view)
- Custom dimensions (user type, plan type, HubSpot lead status, campaign ID)
- Integration with HubSpot (tracking code or Google Tag Manager, GA4 audiences sync)

### Experimentation Framework

**A/B Testing Prioritization (ICE Score):**
- Formula: ICE = (Impact × Confidence × Ease) ÷ 3
- Rating scale: 1-10 for each factor
- Example tests with ICE scores (CTA color, landing page headline, pricing redesign, lead magnet, live chat)

**Test Design & Execution:**
- Test template (hypothesis, metric, sample size, duration, success criteria, variants, tools)
- Statistical significance requirements (95% confidence minimum, 1,000 visitors/variant, don't stop early)
- Test velocity target (4-6 tests/month for Series A, 30-40% win rate realistic)

**Common Experiments:**
- Landing page tests (headline, CTA copy, form length, social proof placement, hero image)
- Ad tests (creative format, messaging angle, audience targeting, landing page destination)
- Email tests (subject line length, personalization, send time, CTA placement)

### Handoff Protocols

**MQL → SQL Handoff (Marketing → Sales):**
- SQL definition criteria (job title, company size, budget, timeline, engagement)
- HubSpot workflow (lead score >75 → SDR email → qualification call → mark SQL → assign AE)
- SLA (SDR responds in 4 hours, AE books demo in 24 hours, first demo within 3 business days)

**SQL → Opportunity Handoff (Sales → RevOps):**
- Opportunity creation (after first demo, required fields: company, deal value, close date, stage)
- Pipeline stages (Discovery → Demo → Proposal → Negotiation → Closed Won/Lost)
- Marketing support post-SQL (retargeting ads, case studies, ROI calculator, customer webinars, executive briefings)

**Lost Opportunity Handoff (Sales → Marketing):**
- Recycle to nurture (reasons: no budget, bad timing, wrong fit)
- Nurture action (move to "Nurture" list, quarterly check-in emails, webinar invites)
- Re-engagement timeline (6-12 months, SDR re-qualification)
- Closed lost reasons tracking (price, missing features, chose competitor, no budget, bad timing, champion left)
- Use lost reasons to inform product roadmap, pricing, competitive positioning, messaging

## How It Works

### Campaign Planning & Execution

**Step 1: Full-Funnel Strategy Development**
1. Map buyer journey (awareness → consideration → decision → purchase)
2. Assign tactics to each funnel stage (TOFU: paid social, display, SEO; MOFU: paid search, retargeting, gated content; BOFU: brand search, free trial, demos)
3. Set stage-specific metrics (TOFU: traffic, brand lift; MOFU: MQLs, demo requests; BOFU: SQLs, pipeline $)
4. Allocate budget by stage (TOFU 30%, MOFU 40%, BOFU 30% recommended)

**Step 2: Campaign Brief Creation**
1. Define campaign name, objective, budget, duration
2. Identify target audience (ICP, personas, company size, geography)
3. Choose channels (LinkedIn, Google, Meta, email, partnerships)
4. Define offer (gated content, webinar, free trial, demo)
5. Set success metrics (primary: SQLs/pipeline $; secondary: MQLs, conversion rates)
6. Establish handoff protocol (SQL criteria, routing, SLA)

**Step 3: HubSpot Campaign Setup**
1. Create campaign in HubSpot Marketing → Campaigns
2. Tag all assets with campaign ID (landing pages, emails, ads, forms)
3. Configure UTM parameters (source, medium, campaign, content, term)
4. Set up lead scoring rules (+20 for content download, +30 for demo request)
5. Create attribution reports (first-touch for awareness, multi-touch for full journey)

**Step 4: Campaign Launch**
1. Launch paid campaigns (LinkedIn, Google, Meta)
2. Publish landing pages and forms
3. Send email announcement (to existing database)
4. Activate partnerships (co-marketing push)
5. Monitor metrics daily (traffic, conversion rates, leads, SQLs)

**Step 5: Optimization**
1. Review campaign performance after 2 weeks
2. Identify underperforming channels (pause if CAC >2x target)
3. Scale winning channels (increase budget 20% weekly if CAC < target)
4. A/B test landing pages and ad copy
5. Adjust messaging based on early signals

**Step 6: Reporting**
1. Weekly dashboard review (MQLs, SQLs, pipeline $, CAC by channel)
2. Monthly insights report (top performers, underperformers, action items)
3. Quarterly business review (overall performance, learnings, next quarter priorities)

### Paid Media Campaign Setup

**Step 7: LinkedIn Ads Implementation**
1. Create campaign structure (campaign group → campaigns by funnel stage → ad sets by audience)
2. Set up targeting (company size 50-5,000 employees, job titles Director+, industries: SaaS/Tech)
3. Create matched audiences (website retargeting with Insight Tag, uploaded email lists)
4. Design creatives (3-5 variants: thought leadership, social proof, problem-solution, demo-first)
5. Set budget ($50/day per campaign to start)
6. Launch and monitor CAC (target $150-400 per SQL)
7. Scale winning campaigns (20% weekly if CAC < target)

**Step 8: Google Ads Implementation**
1. Prioritize campaign types (Brand → Competitor → Solution → Product Category → Display Retargeting)
2. Build keyword lists (brand: exact match, high bid; competitor: "[Competitor] alternative"; solution: "best [category]")
3. Create responsive search ads (15 headlines: value props, features, social proof, CTAs; 4 descriptions)
4. Set negative keywords (maintain list of 100+: free, cheap, jobs, career, reviews)
5. Start with Manual CPC for control
6. Switch to Target CPA after 50+ conversions
7. Monitor and optimize (target $80-250 CAC)

**Step 9: Meta Ads Implementation (if appropriate for ACV)**
1. Validate fit (ACV <$10k, visual product, SMB audience)
2. Create conversion campaign objective
3. Set up audiences (lookalike 1% of converters, interest targeting: business software, retargeting: 30-day visitors)
4. Design video creatives (1:1 or 9:16 for Stories, hook in first 3 seconds, add captions)
5. Launch with $5k/month budget
6. Optimize based on cost per lead (target $60-200 CAC)

### SEO Strategy Implementation

**Step 10: Technical SEO Foundation**
1. Complete pre-launch checklist (sitemap, robots.txt, HTTPS, page speed, Core Web Vitals, structured data)
2. Submit sitemap to Google Search Console
3. Set up hreflang tags for international (en-US, en-GB, de-DE, fr-FR)
4. Run quarterly technical audit with Screaming Frog
5. Fix critical issues immediately, high priority within 1 month, medium within 3 months

**Step 11: Keyword Research & Content Planning**
1. Identify seed keywords (product category, main use cases)
2. Use tools (Ahrefs, SEMrush, or free: Google Keyword Planner + Search Console)
3. Analyze keywords (volume, difficulty, intent, SERP features)
4. Prioritize Tier 1 BOFU keywords first (quick wins, high intent)
5. Create content brief for each target keyword (outline, word count, internal links, CTAs)

**Step 12: On-Page Optimization**
1. Follow on-page SEO template (URL, title tag, meta description, H1, H2-H6 structure)
2. Write 2,000-3,000 word comprehensive content
3. Include primary keyword naturally (1-2% density)
4. Add 3-5 internal links to relevant pages
5. Add 2-3 external links to authoritative sources
6. Optimize images (alt text, descriptive filenames, compression)
7. Implement schema markup (Article, HowTo, FAQ)

**Step 13: Link Building Execution**
1. Prioritize Digital PR (publish original research, industry reports, pitch journalists)
2. Guest posting (target Domain Authority 40+ sites, use 70% branded anchor text)
3. Partnerships (exchange homepage links with complementary SaaS tools)
4. Community engagement (Reddit, Quora, industry forums - provide value, not spam)
5. Track link velocity (5-10 links/month for new sites, 20-30 after 6 months)
6. Monitor Google Search Console for manual actions

**Step 14: Content Publishing & Refresh**
1. Publish 4 TOFU posts/month (guides, listicles)
2. Publish 2 MOFU posts/month (comparisons, how-tos)
3. Publish 1 BOFU post/month (product pages, case studies)
4. Refresh 2 existing posts/month (update stats, add sections, improve SEO)
5. Monitor Search Console for ranking drops (refresh immediately)

### Partnership Development

**Step 15: Strategic Partnership Establishment**
1. Identify potential partners (similar ICP, complementary product, similar scale)
2. Use tools (BuiltWith, SimilarWeb, LinkedIn Sales Nav) for research
3. Send outreach email (template provided in playbook)
4. Define partnership scope (product integration depth, co-marketing commitment, revenue share)
5. Create partnership agreement (12-24 month term, success metrics, 90-day exit clause)
6. Build co-branded assets (landing page, webinar deck, one-pager)
7. Train partner sales team (product demo, pitch deck, objection handling)
8. Set up HubSpot tracking (UTM parameters, partner portal, dashboard)
9. Schedule QBRs (quarterly performance review, pipeline, blockers)

**Step 16: Affiliate Program Launch**
1. Choose platform (PartnerStack for B2B SaaS, Impact for enterprise, Rewardful for lightweight)
2. Define commission structure (30% recurring for influencers, 20% for bloggers, $500 for customers)
3. Create "Become an Affiliate" page on website
4. Recruit affiliates (outbound to bloggers/YouTubers, promote in product, attend events)
5. Build affiliate enablement kit (brand assets, pre-written content, tracking links, collateral)
6. Launch program and monitor performance (partner-sourced pipeline $ in HubSpot)

**Step 17: Co-Marketing Campaign Execution**
1. Plan joint webinar 6 weeks ahead (define topic, assign roles, create landing page)
2. Promote 4 weeks ahead (3 emails: announcement, reminder, last chance; 8-10 social posts per partner)
3. Run paid ads ($2k budget for LinkedIn ads → landing page)
4. Execute webinar (60-min format: 5min intro, 40min content, 15min Q&A)
5. Follow up 1 week after (send recording, 3-email nurture sequence over 2 weeks)
6. Split leads (each partner owns their referred leads)
7. Report results (attendees, pipeline generated, next steps)

### Attribution & Analytics

**Step 18: Attribution Setup**
1. Choose attribution model (multi-touch W-shaped recommended for hybrid PLG/Sales)
2. Set up HubSpot attribution reports (Marketing → Reports → Attribution)
3. Compare models (first-touch for awareness credit, multi-touch for full journey)
4. Configure custom reports (pipeline by channel, campaign ROI, CAC by source)

**Step 19: Dashboard Configuration**
1. Build weekly performance dashboard (traffic, MQLs, SQLs, pipeline $, CAC, channel mix)
2. Build monthly executive dashboard (marketing-sourced pipeline, revenue, blended CAC, MQL→SQL rate, ROMI)
3. Set up Google Analytics 4 events (sign_up, demo_request, pricing_view)
4. Create custom dimensions (user type, plan type, HubSpot lead status, campaign ID)
5. Review dashboards weekly (tactical adjustments), report monthly (strategic review)

### Experimentation & Optimization

**Step 20: A/B Test Prioritization**
1. Brainstorm potential tests (landing page, ad creative, email subject lines)
2. Score each test using ICE framework (Impact 1-10, Confidence 1-10, Ease 1-10)
3. Calculate ICE score: (Impact × Confidence × Ease) ÷ 3
4. Prioritize tests with ICE > 7.0
5. Run 4-6 tests per month

**Step 21: Test Execution**
1. Write test hypothesis (clear, measurable, time-bound)
2. Define success metric (demo requests, signups, MQLs)
3. Calculate sample size (minimum 1,000 visitors per variant, use Optimizely calculator)
4. Set duration (run until significance, minimum 2 weeks)
5. Launch test (HubSpot A/B test for landing pages, Google Optimize, or platform-native)
6. Monitor daily (don't stop early - avoid false positives)
7. Declare winner at 95% confidence
8. Document learnings (winners and losers both provide insights)

### International Expansion

**Step 22: Market Entry Planning**
1. Prioritize markets (US → UK → DACH → France → Canada recommended for Series A)
2. Allocate budget (US 50%, UK 20%, DACH 15%, France 10%, Canada 5%)
3. Complete localization checklist (website translation, local currency, GDPR compliance)
4. Hire local resources (sales reps or partner with local agencies)
5. Adapt paid channel mix (EU: 40% LinkedIn, 25% Google, 20% SEO, 15% Partnerships)

**Step 23: EU Market Entry**
1. Ensure GDPR compliance (double opt-in for email, explicit consent tracking in HubSpot)
2. Translate website and landing pages (German for DACH, French for France)
3. Display prices in EUR (include VAT)
4. Set up local payment methods (SEPA, iDEAL)
5. Launch paid campaigns (LinkedIn most effective for B2B EU, Google second)
6. Establish local partnerships (co-marketing with EU-based SaaS companies)

**Step 24: US/Canada Market Entry**
1. Adapt messaging (direct, ROI-focused, less formal than EU)
2. Allocate budget (35% Google, 30% LinkedIn, 20% SEO, 15% Partnerships)
3. Hire US-based SDRs/AEs (or partner with US sales agency)
4. Launch paid campaigns (Google Ads + LinkedIn equal priority)
5. Activate partnerships (industry associations, review sites: G2, Capterra)
6. Ensure fast lead follow-up (<4 hour SLA critical for US market)

## Technical Details

### Tech Stack Integration

**HubSpot CRM:**
- Campaign tracking and UTM attribution
- Lead scoring and qualification workflows
- MQL→SQL automation and routing
- Multi-touch attribution reporting
- Deal pipeline and revenue tracking
- Sales enablement content library

**Google Analytics 4:**
- Traffic analysis and source attribution
- Conversion tracking (sign_up, demo_request, pricing_view)
- Funnel optimization (drop-off analysis)
- Custom dimensions (user type, plan type, HubSpot lead status, campaign ID)
- Integration with HubSpot (tracking code, audience sync)

**Google Search Console:**
- Keyword performance monitoring
- Technical SEO issue detection
- Indexing status and sitemap management
- Core Web Vitals tracking

**LinkedIn Campaign Manager:**
- B2B paid social campaigns
- Audience targeting (company, job title, industry)
- Lead Gen Forms (native HubSpot integration)
- Conversion tracking and attribution

**Google Ads:**
- Paid search (Search, Display, YouTube)
- Keyword bidding and optimization
- Responsive search ads
- Conversion tracking (Google Ads ↔ HubSpot integration)

**Meta Ads Manager:**
- Facebook and Instagram campaigns
- Audience targeting (interests, lookalikes, retargeting)
- Creative testing and optimization
- Pixel tracking and conversion optimization

### HubSpot Implementation Details

**Campaign Setup:**
```
1. Marketing → Campaigns → Create Campaign
2. Campaign Name: Q2-2025-LinkedIn-ABM-Enterprise
3. Tag assets: Landing pages, emails, ads, forms with campaign ID
4. UTM structure:
   - utm_source={channel} // linkedin, google, facebook, organic
   - utm_medium={type} // cpc, display, email, organic
   - utm_campaign={campaign-id} // q2-2025-linkedin-abm-enterprise
   - utm_content={variant} // ad-variant-a, email-1
   - utm_term={keyword} // [for paid search only]
```

**Lead Scoring Configuration:**
```
Settings → Marketing → Lead Scoring

Campaign Engagement:
- Downloaded gated content: +10 points
- Attended webinar: +15 points
- Requested demo: +30 points
- Visited pricing page 3+ times: +20 points

Channel Quality:
- Organic search: +15 points (high intent)
- LinkedIn: +5 points
- Google Search: +10 points
- Display/social: +3 points

Demographic:
- Job title matches (Director+): +10 points
- Company size matches (50-5,000): +10 points
- Industry matches: +5 points

MQL Threshold: 75 points
SQL Criteria: 75+ points + BANT qualified
```

**Multi-Touch Attribution Setup:**
```
Marketing → Reports → Attribution → Select Model: W-Shaped

W-Shaped Attribution (40-20-40):
- First Touch: 40% credit (awareness)
- Middle Touch: 20% credit distributed (consideration)
- Last Touch: 40% credit (decision)

Reports to Create:
- Pipeline $ by Channel (multi-touch)
- Revenue by Campaign (multi-touch)
- CAC by Source (last-touch for conversion credit)
- MQL attribution (first-touch for awareness credit)
```

### CAC Calculation

**Blended CAC Formula:**
```
Blended CAC = Total Marketing + Sales Spend ÷ New Customers Acquired

Example:
Marketing Spend: $40k/month
Sales Spend: $60k/month (salaries, commissions, tools)
New Customers: 20/month
Blended CAC: ($40k + $60k) ÷ 20 = $5,000

Target: <1/3 of LTV (Lifetime Value)
Series A Benchmark: $3,000-$8,000 blended CAC for B2B SaaS
```

**Channel-Specific CAC:**
```
Channel CAC = Channel Spend ÷ Customers from Channel

LinkedIn:
Spend: $15k/month
Customers: 10
CAC: $1,500

Google Search:
Spend: $12k/month
Customers: 20
CAC: $600

Track in HubSpot:
- Create custom report: Deals Closed by Original Source
- Calculate: Ad Spend ÷ Deals = CAC by Channel
- Optimize: Scale channels with CAC < 1/3 LTV
```

### Benchmark Metrics (B2B SaaS Series A)

**Channel Performance:**
| Channel | CTR | CVR | CAC | MQL→SQL |
|---------|-----|-----|-----|---------|
| LinkedIn Ads | 0.4-0.9% | 1-3% | $150-400 | 10-20% |
| Google Search | 2-5% | 3-7% | $80-250 | 15-25% |
| SEO Organic | 1-3% | 2-5% | $50-150 | 12-22% |
| Email Marketing | 15-25% | 2-5% | $20-80 | 8-15% |
| Partnerships | N/A | 5-10% | $100-300 | 20-35% |

**Funnel Conversion Rates:**
- Website Visitor → MQL: 1-3%
- MQL → SQL: 10-20%
- SQL → Opportunity: 50-70%
- Opportunity → Closed Won: 20-35%
- Overall: Visitor → Customer: 0.02-0.15%

**Budget Allocation (Series A $40k-60k/month):**
- 40% Paid Acquisition (LinkedIn + Google): $16k-24k
- 25% Content/SEO: $10k-15k
- 20% Partnerships: $8k-12k
- 10% Tools/Automation: $4k-6k
- 5% Experiments/Testing: $2k-3k

## Best Practices

### Campaign Planning Best Practices

- **Full-funnel always** - Don't focus only on BOFU; build awareness and nurture
- **Set clear success metrics upfront** - Define what "successful campaign" means before launch
- **Plan 4-6 weeks ahead** - Major campaigns need time for asset creation and coordination
- **Test messaging before scaling** - Run small test ($1k-2k) before committing full budget
- **Monitor daily during launch week** - First 48 hours reveal if campaign will succeed
- **Use UTM parameters consistently** - No UTMs = no attribution = can't optimize
- **Document campaign briefs** - Repeatable process > ad-hoc campaigns
- **Review weekly, report monthly** - Quick tactical adjustments prevent wasted spend

### Paid Media Best Practices

- **LinkedIn for B2B always** - Highest quality B2B leads despite higher CAC
- **Start Manual CPC, then automate** - Learn before letting algorithm optimize
- **Test 3-5 creative variants** - One creative = no learning
- **Protect brand terms in Google** - Always run brand campaign (exact match, high bid)
- **Use negative keywords religiously** - Save 20-30% budget by excluding irrelevant searches
- **Scale winners 20% weekly** - Don't double overnight (algorithm needs to adjust)
- **Pause losers fast** - 2-week minimum test, then kill if CAC >2x target
- **Retarget website visitors** - 5-10x higher conversion than cold traffic

### SEO Best Practices

- **Technical foundation first** - Can't rank with slow site, broken links, no sitemap
- **Target one keyword per page** - Focused content ranks better than broad
- **Longer content wins** - 2,000-3,000 words for competitive keywords
- **Build links consistently** - 10-20 links/month steady > 100 links one month then nothing
- **Update top content quarterly** - Google favors fresh, current content
- **Internal linking matters** - Helps new content rank faster
- **Track rankings monthly** - Know what's working, double down
- **Patience required** - SEO takes 3-6 months to show results

### Partnership Best Practices

- **Quality over quantity** - 3 great partners > 20 weak affiliates
- **Align on ICP first** - Overlapping audience is non-negotiable
- **Co-create value** - Webinars, content, integrations that benefit both audiences
- **Track rigorously** - Use UTMs and HubSpot partner tracking (no attribution = trust issues)
- **QBRs are critical** - Quarterly reviews keep partnerships alive
- **Start small, scale wins** - Test with one co-webinar before committing to large integration
- **Compensate fairly** - 20-30% commission for affiliates, revenue share for strategic partners

### Attribution & Reporting Best Practices

- **Use multi-touch for hybrid motion** - First-touch and last-touch both miss the middle
- **Review weekly, adjust fast** - Don't wait for month-end to optimize
- **Segment by ICP fit** - CAC and win rate vary dramatically by customer quality
- **Compare channel efficiency** - CAC alone isn't enough; look at SQL quality and sales cycle length
- **Share insights, not just data** - "LinkedIn outperformed because..." > "LinkedIn: 50 MQLs"
- **Make data accessible** - Sales, product, exec team need dashboards too
- **Benchmark against yourself** - Month-over-month improvement matters more than industry benchmarks

## Common Pitfalls to Avoid

- **Don't scale before optimizing** - Fix CAC issues before increasing budget
- **Don't ignore MQL quality** - High MQL volume with low SQL conversion = waste
- **Don't set up campaigns without UTM parameters** - No attribution = flying blind
- **Don't run paid ads without landing pages** - Sending traffic to homepage = 50%+ wasted spend
- **Don't expect SEO results in 30 days** - SEO is 3-6 month investment minimum
- **Don't expand internationally without localization** - Translated landing page alone is insufficient
- **Don't let partnerships die** - Quarterly check-ins or partnership becomes inactive
- **Don't A/B test without statistical significance** - False positives lead to bad decisions
- **Don't optimize for vanity metrics** - MQLs and traffic matter less than pipeline $ and revenue
- **Don't run experiments without documentation** - Can't learn if you don't track what you tested

## Resources Included

### Reference Guides in `references/` Directory

**hubspot-workflows.md:**
- Pre-built HubSpot workflow templates (lead scoring, MQL→SQL routing, nurture sequences, partner lead assignment)
- Step-by-step workflow setup instructions
- Trigger conditions, actions, and goal criteria

**campaign-templates.md:**
- Ready-to-use campaign briefs (LinkedIn ABM, Google Search, SEO content, partnership webinar)
- Success metrics templates by campaign type
- Budget allocation and timeline templates

**international-playbooks.md:**
- Market-specific tactics for EU, US, Canada expansion
- Localization checklists per market (website, product, pricing, legal, payment)
- Budget allocation and expected ROI by market
- GDPR compliance requirements and setup

**attribution-guide.md:**
- Deep dive on multi-touch attribution models
- HubSpot attribution setup step-by-step
- Custom report templates (pipeline by channel, campaign ROI, CAC by source)
- Interpretation guidelines (how to use attribution data for optimization)

### Scripts in `scripts/` Directory

**calculate_cac.py:**
- Input: Marketing spend, sales spend, customers acquired (total and by channel)
- Output: Blended CAC, channel-specific CAC, CAC trends over time
- Comparison: Actual CAC vs. target CAC (based on LTV)
- Usage: `python scripts/calculate_cac.py --marketing 40000 --sales 60000 --customers 20`

**experiment_calculator.py:**
- Input: Current conversion rate, expected lift, confidence level
- Output: Required sample size per variant, test duration estimate
- Significance: Calculates statistical significance when test complete
- Usage: `python scripts/experiment_calculator.py --baseline 0.05 --lift 0.20 --confidence 0.95`

### Assets in `assets/` Directory

**campaign-brief-template.docx:**
- Editable campaign planning document
- Sections: Objective, audience, channels, offer, budget, timeline, success metrics, handoff protocol
- Examples for LinkedIn, Google, SEO campaigns

**dashboard-template.xlsx:**
- Pre-configured performance dashboard (weekly and monthly views)
- Metrics: Traffic, MQLs, SQLs, pipeline $, CAC, ROMI
- Charts: Channel mix, funnel conversion, CAC trends
- Formulas: Auto-calculates CAC, conversion rates, ROMI
